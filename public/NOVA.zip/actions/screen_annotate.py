"""
Live screen overlay annotation for JARVIS.
Draws directly on screen via transparent overlay window (like a presentation pointer).
Auto-discovered by core.action_loader.
"""
from __future__ import annotations
import sys
import json
import time
import platform
import math
import threading
from copy import deepcopy
from pathlib import Path

try:
    from PyQt6.QtCore import (
        Qt, QTimer, QPoint, QRect, QRectF, QPropertyAnimation, QEasingCurve, pyqtSignal, QObject, QThread
    )
    from PyQt6.QtGui import (
        QPainter, QPen, QColor, QBrush, QFont, QFontMetrics, QPolygon, QPainterPath
    )
    from PyQt6.QtWidgets import QApplication, QWidget
    _QT = True
except ImportError:
    _QT = False

try:
    import pyautogui
    _PYAUTO = True
except ImportError:
    _PYAUTO = False


# Global overlay instance (single instance)
_overlay_instance = None
_dispatcher = None


class _OverlayDispatcher(QObject):
    """Move overlay mutations onto the Qt GUI thread."""

    request = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.request.connect(self._apply)
        self._transition = None

    def _apply(self, payload):
        annotations, duration = payload[:2]
        acknowledgement = payload[2] if len(payload) > 2 else None
        try:
            overlay = _get_overlay()
            # Replace the frame immediately; old expiry/fade callbacks must
            # never hide a newer teaching target.
            if self._transition is not None:
                self._transition.stop()
                self._transition = None
            if overlay._fade_anim is not None:
                overlay._fade_anim.stop()
                overlay._fade_anim = None
            overlay._expiry_timer.stop()
            self._render((annotations, duration))
            if acknowledgement is not None:
                acknowledgement["visible"] = bool(overlay.isVisible())
        except Exception as error:
            if acknowledgement is not None:
                acknowledgement["error"] = str(error)
        finally:
            if acknowledgement is not None:
                acknowledgement["event"].set()

    def _render(self, payload):
        annotations, duration = payload
        overlay = _get_overlay()
        overlay.clear_annotations()
        if not annotations:
            overlay._pulse_timer.stop()
            overlay._expiry_timer.stop()
            overlay.setWindowOpacity(1.0)
            overlay.hide()
            return
        # Show at full window opacity. Some Windows compositor configurations
        # do not animate top-level window opacity reliably; setting it to zero
        # first left a perfectly painted overlay completely invisible.
        overlay.setWindowOpacity(1.0)
        geometry = overlay.geometry()
        for annotation in _to_overlay_coordinates(annotations, geometry.x(), geometry.y()):
            overlay.add_annotation(annotation)
        overlay.show()
        overlay.update()
        if platform.system() == "Windows":
            overlay.raise_()
        if duration > 0:
            overlay._expiry_timer.start(duration)
        if any(a.get("type") in ("spotlight", "glow", "pointer") for a in annotations):
            overlay._pulse_started = time.monotonic()
            overlay._pulse_timer.start()
        else:
            overlay._pulse_timer.stop()


def _get_dispatcher(app: QApplication):
    global _dispatcher
    if _dispatcher is None:
        _dispatcher = _OverlayDispatcher()
        _dispatcher.moveToThread(app.thread())
    return _dispatcher


def _to_overlay_coordinates(annotations: list[dict], origin_x: int, origin_y: int):
    """Convert absolute desktop coordinates to the overlay's virtual origin."""
    translated = []
    point_keys = ("center", "pt1", "pt2", "position")
    for annotation in annotations:
        item = deepcopy(annotation)
        for key in point_keys:
            point = item.get(key)
            if isinstance(point, (list, tuple)) and len(point) >= 2:
                item[key] = [int(point[0]) - origin_x, int(point[1]) - origin_y]
        translated.append(item)
    return translated


class AnnotationOverlay(QWidget):
    """Transparent full-screen overlay for drawing annotations."""

    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool |
            Qt.WindowType.WindowTransparentForInput |
            Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_AlwaysStackOnTop)

        # Cover the full virtual desktop so highlights use the same absolute
        # coordinates as PyAutoGUI, including multi-monitor layouts.
        app = QApplication.instance()
        if app:
            screens = app.screens()
            geometry = screens[0].geometry()
            for screen in screens[1:]:
                geometry = geometry.united(screen.geometry())
            self.setGeometry(geometry)
        else:
            self.setGeometry(0, 0, 1920, 1080)

        self._annotations = []
        self._fade_anim = None
        self._expiry_timer = QTimer(self)
        self._expiry_timer.setSingleShot(True)
        self._expiry_timer.timeout.connect(self.fade_out)
        self._pulse_started = time.monotonic()
        self._pulse_timer = QTimer(self)
        self._pulse_timer.setInterval(40)
        self._pulse_timer.timeout.connect(self.update)

    def add_annotation(self, annotation: dict):
        """Add an annotation and trigger repaint."""
        self._annotations.append(annotation)
        self.update()

    def clear_annotations(self):
        """Clear all annotations."""
        self._annotations = []
        self.update()

    def paintEvent(self, event):
        if not self._annotations:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        pulse = (math.sin((time.monotonic() - self._pulse_started) * 2.2) + 1.0) / 2.0

        for ann in self._annotations:
            self._draw_annotation(painter, ann, pulse)

    def _draw_annotation(self, painter: QPainter, ann: dict, pulse: float = 0.5):
        ann_type = ann.get("type", "").lower()
        color = QColor(*ann.get("color", [0, 255, 255, 255]))
        thickness = ann.get("thickness", 4)

        pen = QPen(color, thickness, Qt.PenStyle.SolidLine,
                   Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen)

        if ann_type == "circle":
            center = ann.get("center")
            radius = ann.get("radius", 60)
            if center:
                painter.drawEllipse(QPoint(*center), radius, radius)

        elif ann_type in ("rectangle", "box"):
            pt1 = ann.get("pt1")
            pt2 = ann.get("pt2")
            if pt1 and pt2:
                painter.drawRect(QRect(QPoint(*pt1), QPoint(*pt2)).normalized())

        elif ann_type == "arrow":
            pt1 = ann.get("pt1")
            pt2 = ann.get("pt2")
            if pt1 and pt2:
                p1, p2 = QPoint(*pt1), QPoint(*pt2)
                painter.drawLine(p1, p2)
                self._draw_arrowhead(painter, p1, p2, color, thickness)

        elif ann_type == "line":
            pt1 = ann.get("pt1")
            pt2 = ann.get("pt2")
            if pt1 and pt2:
                painter.drawLine(QPoint(*pt1), QPoint(*pt2))

        elif ann_type == "crosshair":
            center = ann.get("center")
            size = ann.get("size", 40)
            if center:
                x, y = center
                painter.drawLine(x - size, y, x + size, y)
                painter.drawLine(x, y - size, x, y + size)

        elif ann_type == "text":
            text = ann.get("text", "")
            pos = ann.get("position")
            font_size = ann.get("font_size", 24)
            if text and pos:
                font = QFont("Segoe UI", font_size, QFont.Weight.Bold)
                painter.setFont(font)
                painter.drawText(QPoint(*pos), text)

        elif ann_type == "label":
            text = str(ann.get("text", ""))
            pt1 = ann.get("pt1")
            pt2 = ann.get("pt2")
            font_size = int(ann.get("font_size", 14))
            if text and pt1 and pt2:
                font = QFont("Segoe UI", font_size, QFont.Weight.Bold)
                metrics = QFontMetrics(font)
                rect = QRect(QPoint(*pt1), QPoint(*pt2)).normalized()
                text = metrics.elidedText(text, Qt.TextElideMode.ElideRight, max(20, rect.width() - 12))
                painter.setFont(font)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(*ann.get("background", [245, 158, 11, 235])))
                painter.drawRoundedRect(rect, 5, 5)
                painter.setPen(QColor(*ann.get("text_color", [15, 23, 42, 255])))
                painter.drawText(rect.adjusted(6, 0, -6, 0), Qt.AlignmentFlag.AlignVCenter, text)
                painter.setBrush(Qt.BrushStyle.NoBrush)

        elif ann_type == "spotlight":
            pt1, pt2 = ann.get("pt1"), ann.get("pt2")
            if pt1 and pt2:
                target = QRect(QPoint(*pt1), QPoint(*pt2)).normalized().adjusted(-7, -7, 7, 7)
                mask = QPainterPath()
                mask.setFillRule(Qt.FillRule.OddEvenFill)
                mask.addRect(QRectF(self.rect()))
                mask.addRoundedRect(QRectF(target), 12, 12)
                painter.fillPath(mask, QColor(3, 8, 20, int(70 + pulse * 22)))

        elif ann_type == "glow":
            pt1, pt2 = ann.get("pt1"), ann.get("pt2")
            if pt1 and pt2:
                rect = QRect(QPoint(*pt1), QPoint(*pt2)).normalized().adjusted(-5, -5, 5, 5)
                glow = QColor(*ann.get("color", [40, 225, 255, 255]))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                for width, alpha in ((11, 24), (7, 48), (3, int(170 + pulse * 75))):
                    glow.setAlpha(alpha)
                    painter.setPen(QPen(glow, width, Qt.PenStyle.SolidLine,
                                        Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                    painter.drawRoundedRect(rect, 10, 10)

        elif ann_type == "pointer":
            start, end = ann.get("pt1"), ann.get("pt2")
            if start and end:
                p1, p2 = QPoint(*start), QPoint(*end)
                accent = QColor(*ann.get("color", [40, 225, 255, 255]))
                accent.setAlpha(int(205 + pulse * 50))
                painter.setPen(QPen(accent, 3, Qt.PenStyle.SolidLine,
                                    Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.drawLine(p1, p2)
                self._draw_arrowhead(painter, p1, p2, accent, 3)
                badge = QRect(p1.x() - 23, p1.y() - 13, 46, 26)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(8, 22, 38, 235))
                painter.drawRoundedRect(badge, 13, 13)
                painter.setPen(QPen(accent, 1.5))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(badge, 13, 13)
                painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, "NOVA")

        elif ann_type == "number":
            center = ann.get("center")
            if center:
                radius = int(ann.get("radius", 13))
                point = QPoint(*center)
                accent = QColor(*ann.get("color", [45, 224, 255, 255]))
                painter.setPen(QPen(accent, 2))
                painter.setBrush(QColor(8, 22, 38, 245))
                painter.drawEllipse(point, radius, radius)
                painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                painter.setPen(QColor(245, 253, 255, 255))
                painter.drawText(QRect(point.x() - radius, point.y() - radius,
                                       radius * 2, radius * 2),
                                 Qt.AlignmentFlag.AlignCenter, str(ann.get("value", "1")))

        elif ann_type == "highlight":
            pt1 = ann.get("pt1")
            pt2 = ann.get("pt2")
            alpha = int(ann.get("alpha", 0.25) * 255)
            if pt1 and pt2:
                fill_color = QColor(color.red(), color.green(), color.blue(), alpha)
                painter.fillRect(QRect(QPoint(*pt1), QPoint(*pt2)).normalized(), fill_color)

    def _draw_arrowhead(self, painter: QPainter, p1: QPoint, p2: QPoint, color: QColor, thickness: int):
        """Draw arrowhead at p2 pointing from p1."""
        import math
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        length = math.hypot(dx, dy)
        if length == 0:
            return

        dx /= length
        dy /= length

        head_len = max(15, thickness * 5)
        angle = math.pi / 6

        x1 = p2.x() - head_len * (dx * math.cos(angle) - dy * math.sin(angle))
        y1 = p2.y() - head_len * (dx * math.sin(angle) + dy * math.cos(angle))
        x2 = p2.x() - head_len * (dx * math.cos(-angle) - dy * math.sin(-angle))
        y2 = p2.y() - head_len * (dx * math.sin(-angle) + dy * math.cos(-angle))

        painter.drawLine(p2, QPoint(int(x1), int(y1)))
        painter.drawLine(p2, QPoint(int(x2), int(y2)))

    def fade_out(self, duration: int = 1500):
        """Fade out the temporary teaching overlay."""
        self._pulse_timer.stop()
        self._fade_anim = QPropertyAnimation(self, b"windowOpacity")
        self._fade_anim.setDuration(duration)
        self._fade_anim.setStartValue(1.0)
        self._fade_anim.setEndValue(0.0)
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_anim.finished.connect(self.hide)
        self._fade_anim.start()


def _get_overlay() -> AnnotationOverlay:
    """Get or create the global overlay instance."""
    global _overlay_instance
    if _overlay_instance is None:
        _overlay_instance = AnnotationOverlay()
    return _overlay_instance


def _get_mouse_position() -> tuple[int, int]:
    """Get current mouse position."""
    if _PYAUTO:
        return pyautogui.position()
    return (0, 0)


def _parse_annotations(parameters: dict) -> list[dict]:
    """Parse annotation instructions from parameters."""
    annotations = []
    if "type" in parameters:
        annotations.append(parameters)
    if "annotations" in parameters:
        ann_list = parameters["annotations"]
        if isinstance(ann_list, list):
            annotations.extend(ann_list)
    return annotations


def _run_overlay(annotations: list[dict], duration: int = 3000):
    """Run the overlay in the Qt event loop."""
    if not _QT:
        return "PyQt6 not available"

    app = QApplication.instance()
    if app is None:
        return "No Qt application running"

    dispatcher = _get_dispatcher(app)
    acknowledgement = {"event": threading.Event(), "visible": False}
    payload = (annotations, duration, acknowledgement)
    if QThread.currentThread() == app.thread():
        dispatcher._apply(payload)
        app.processEvents()
    else:
        dispatcher.request.emit(payload)

    if not acknowledgement["event"].wait(2.0):
        return "Overlay request was queued but could not be confirmed on screen."
    if acknowledgement.get("error"):
        return f"Overlay could not be shown: {acknowledgement['error']}"
    if not acknowledgement.get("visible"):
        return "Overlay could not be shown because its window is not visible."
    return f"Overlay shown with {len(annotations)} annotation(s) for {duration}ms"


def run(parameters: dict, player=None, speak=None, response=None, session_memory=None) -> str:
    """
    Show live screen overlay annotations.

    Parameters:
    - type: "circle" | "rectangle" | "arrow" | "line" | "text" | "highlight" | "crosshair"
    - center: [x, y] for circle/crosshair (defaults to mouse position)
    - radius: int for circle (default 60)
    - pt1, pt2: [x, y] for rectangle/arrow/line/highlight
    - text: string for text type
    - position: [x, y] for text
    - color: [r, g, b] or [r, g, b, a] default cyan [0, 255, 255, 255]
    - thickness: int default 4
    - font_size: int for text (default 24)
    - alpha: float 0-1 for highlight (default 0.25)
    - annotations: list of annotation dicts (for multiple)
    - use_mouse: bool - use current mouse position as reference (default true)
    - duration: milliseconds to show overlay (default 3000); use 0 to keep it visible until cleared
    - clear: bool - clear existing annotations before adding (default true)
    """
    if not _QT:
        return "PyQt6 not installed. Cannot create screen overlay."

    annotations = _parse_annotations(parameters)

    use_mouse = parameters.get("use_mouse", True)
    if use_mouse and _PYAUTO:
        mx, my = _get_mouse_position()
        for ann in annotations:
            ann_type = ann.get("type", "").lower()
            if ann_type in ("circle", "crosshair") and "center" not in ann:
                ann["center"] = [mx, my]
            if ann_type in ("arrow", "line", "rectangle", "box", "highlight") and "pt1" not in ann:
                ann["pt1"] = [mx, my]

    if not annotations:
        if _PYAUTO:
            mx, my = _get_mouse_position()
        else:
            mx, my = 960, 540
        annotations = [{
            "type": "circle",
            "center": [mx, my],
            "radius": 60,
            "color": [0, 255, 255, 255],
            "thickness": 5
        }]

    for ann in annotations:
        if "color" in ann and len(ann["color"]) == 3:
            ann["color"].append(255)

    duration = parameters.get("duration", 3000)

    result = _run_overlay(annotations, duration)

    if player and hasattr(player, 'write_log'):
        desc = parameters.get("description", f"Showed {len(annotations)} annotation(s)")
        player.write_log(f"[ScreenOverlay] {desc}")

    return result


def clear_overlay(parameters: dict = None, player=None, speak=None, response=None, session_memory=None) -> str:
    """Clear the screen overlay."""
    if _QT:
        app = QApplication.instance()
        if app is not None:
            dispatcher = _get_dispatcher(app)
            if QThread.currentThread() == app.thread():
                dispatcher._apply(([], 1))
            else:
                dispatcher.request.emit(([], 1))
    return "Screen overlay cleared"


TOOL = {
    "name": "screen_annotate",
    "description": (
        "Draw live annotations directly on screen via a transparent click-through overlay. "
        "For visual tutoring, prefer a spotlight, pulsing glow and NOVA pointer around a confidently located UI target."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "type": {
                "type": "STRING",
                "description": "Annotation type: circle, rectangle, arrow, line, text, highlight, crosshair"
            },
            "center": {
                "type": "ARRAY",
                "items": {"type": "INTEGER"},
                "description": "Center point [x, y] for circle/crosshair"
            },
            "radius": {
                "type": "INTEGER",
                "description": "Radius for circle (default 60)"
            },
            "pt1": {
                "type": "ARRAY",
                "items": {"type": "INTEGER"},
                "description": "Start point [x, y] for rectangle/arrow/line/highlight"
            },
            "pt2": {
                "type": "ARRAY",
                "items": {"type": "INTEGER"},
                "description": "End point [x, y] for rectangle/arrow/line/highlight"
            },
            "text": {
                "type": "STRING",
                "description": "Text to draw (for text type)"
            },
            "position": {
                "type": "ARRAY",
                "items": {"type": "INTEGER"},
                "description": "Position [x, y] for text"
            },
            "color": {
                "type": "ARRAY",
                "items": {"type": "INTEGER"},
                "description": "RGBA color [r, g, b, a] (default cyan [0, 255, 255, 255])"
            },
            "thickness": {
                "type": "INTEGER",
                "description": "Line thickness (default 4)"
            },
            "font_size": {
                "type": "INTEGER",
                "description": "Font size for text (default 24)"
            },
            "alpha": {
                "type": "NUMBER",
                "description": "Opacity 0-1 for highlight (default 0.25)"
            },
            "annotations": {
                "type": "ARRAY",
                "items": {"type": "OBJECT"},
                "description": "List of multiple annotation objects"
            },
            "use_mouse": {
                "type": "BOOLEAN",
                "description": "Use current mouse position as reference (default true)"
            },
            "duration": {
                "type": "INTEGER",
                "description": "Milliseconds to show overlay before fade out (default 3000)"
            },
            "clear": {
                "type": "BOOLEAN",
                "description": "Clear existing annotations before adding (default true)"
            }
        },
        "required": []
    },
    "handler": run,
}

CLEAR_TOOL = {
    "name": "screen_annotate_clear",
    "description": "Clear the live screen annotation overlay.",
    "parameters": {"type": "OBJECT", "properties": {}},
    "handler": clear_overlay,
}
