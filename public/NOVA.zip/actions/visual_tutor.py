"""Opt-in, screen-aware visual teaching for NOVA.

The tutor only captures the screen in response to a Visual Teaching Mode
request. It can point out controls, but never moves the pointer, clicks,
types, or otherwise operates the computer.
"""
from __future__ import annotations

import json
import threading
import time
import uuid

try:
    from actions.computer_control import computer_control as _computer_control
except Exception:  # pragma: no cover
    _computer_control = None

try:
    from actions.screen_annotate import run as _annotate_run, clear_overlay as _clear_overlay
except Exception:  # pragma: no cover
    _annotate_run = None
    _clear_overlay = None

_TUTOR_STATE = {}
_WATCHERS = {}
_STATE_LOCK = threading.RLock()


def _state_for(session_memory):
    if session_memory is not None:
        try:
            if hasattr(session_memory, "get"):
                state = session_memory.get("visual_tutor_state")
                if state is None:
                    state = {}
                    session_memory["visual_tutor_state"] = state
                return state
            state = getattr(session_memory, "visual_tutor_state", None)
            if state is None:
                state = {}
                setattr(session_memory, "visual_tutor_state", state)
            return state
        except Exception:
            pass
    return _TUTOR_STATE.setdefault("default", {})


def _find_target(target: str, player=None, session_memory=None):
    if not target or _computer_control is None:
        return None
    try:
        result = _computer_control({"action": "screen_find", "description": target},
                                   player=player, session_memory=session_memory)
        data = json.loads(result) if isinstance(result, str) else result
        if not isinstance(data, dict):
            return None
        return tuple(int(data[k]) for k in ("x", "y", "left", "top", "right", "bottom"))
    except Exception:
        return None


def _target_annotations(x: int, y: int, label: str, bounds=None, number=None,
                        include_spotlight=True):
    if bounds:
        left, top, right, bottom = bounds
        left, top, right, bottom = left - 8, top - 8, right + 8, bottom + 8
    else:
        left, top, right, bottom = x - 70, y - 45, x + 70, y + 45
    label_width = max(180, min(360, len(label) * 8 + 28))
    center_y = (top + bottom) // 2
    badge_x = left - 42 if left > 100 else right + 42
    edge_x = left - 5 if badge_x < left else right + 5
    annotations = ([{"type": "spotlight", "pt1": [left, top], "pt2": [right, bottom]}]
                   if include_spotlight else [])
    annotations.extend([
        {"type": "glow", "pt1": [left, top], "pt2": [right, bottom], "color": [45, 224, 255, 255]},
        {"type": "pointer", "pt1": [badge_x, center_y], "pt2": [edge_x, center_y], "color": [45, 224, 255, 255]},
        {"type": "label", "text": label, "pt1": [left, bottom + 10],
         "pt2": [left + label_width, bottom + 44], "font_size": 13,
         "background": [8, 22, 38, 238], "text_color": [225, 250, 255, 255]},
    ])
    if number is not None:
        annotations.append({"type": "number", "center": [left - 7, top - 7],
                            "value": str(number), "color": [45, 224, 255, 255]})
    return annotations


def _highlight_at(x: int, y: int, label: str, duration: int = 0, bounds=None,
                  related_targets=None):
    if _annotate_run is None:
        return "Visual overlay support is unavailable."
    annotations = _target_annotations(x, y, label, bounds, number=1 if label.startswith("Step ") else None)
    for index, target in enumerate(related_targets or [], start=2):
        if isinstance(target, dict):
            title = str(target.get("label") or target.get("target") or f"Related target {index}")
            coords = target.get("coordinates")
        else:
            title, coords = str(target), None
        if not (isinstance(coords, (list, tuple)) and len(coords) == 6):
            continue
        annotations.extend(_target_annotations(coords[0], coords[1], title, coords[2:],
                                               number=index, include_spotlight=False))
    return _annotate_run({"annotations": annotations, "duration": duration,
                          "clear": True, "use_mouse": False})


def _overlay_available(result):
    return isinstance(result, str) and result.lower().startswith("overlay shown")


def _default_steps(task: str):
    """Fallback essentials tour when screen-based lesson planning is unavailable."""
    app_name = (task or "").strip()
    if not app_name or any(generic in app_name.lower() for generic in
                           ("teach me", "current application", "everything", "how to use")):
        app_name = "the visible application"
    return [
        {"title": "Workspace and main controls", "target": f"main workspace or canvas in {app_name}",
         "instruction": "This is the main workspace. The top menus hold commands, and the nearby toolbar holds the tools used most often.",
         "expected_state": "the application main toolbar or workspace is visible"},
        {"title": "Find the key tools", "target": f"primary tools panel in {app_name}",
         "instruction": "Tools change how you work in the main workspace. Choose a tool, then use it in the central work area.",
         "expected_state": "a tool is selected in the application"},
        {"title": "Inspect settings and properties", "target": f"properties or settings panel in {app_name}",
         "instruction": "This panel contains options for the current document, object, or selected tool. Changes here affect the current selection.",
         "expected_state": "the application properties or settings panel is open"},
        {"title": "Save your work", "target": f"save command in {app_name}",
         "instruction": "Save regularly so your project is preserved. Look for Save in the File menu or use the app’s save shortcut.",
         "expected_state": "a save dialog or saved confirmation is visible"},
        {"title": "Export or share the result", "target": f"export command in {app_name}",
         "instruction": "Export creates a deliverable in a format other people or other apps can use. The export options control its format and quality.",
         "expected_state": "the application export options are open"},
    ]


def _plan_essentials(task: str):
    """Use one opt-in screen image to identify the app and plan a beginner tour."""
    try:
        from google.genai import types as gtypes
        from actions.screen_processor import _capture_screen
        from core import gemini

        image_bytes, mime_type = _capture_screen()
        prompt = (
            "You are planning a visual beginner lesson for a desktop app. Identify the app visible in this image. "
            "Create a self-contained tour of its 6 most important beginner skills, so the user does not have to "
            "choose a topic or answer questions. Order from orientation and core workflow through saving/exporting. "
            "Return JSON only in this shape: {\"application\":\"name\",\"steps\":[{\"title\":\"short\","
            "\"target\":\"specific visible UI element\",\"instruction\":\"one short teaching instruction\","
            "\"expected_state\":\"specific screen-visible result that appears after the user follows this step\","
            "\"related_targets\":[{\"target\":\"another visible element\",\"label\":\"short\"}]}]}. "
            "Use visible elements and native app terms. Keep each step actionable and concise. Never ask the user what to learn."
        )
        response = gemini.call(
            [gtypes.Part.from_bytes(data=image_bytes, mime_type=mime_type), prompt],
            tier=gemini.FAST, timeout_ms=12_000,
        )
        if response is None or not response.text:
            return None, None
        raw = response.text.strip()
        parsed = json.loads(raw[raw.find("{"):raw.rfind("}") + 1])
        app_name = str(parsed.get("application") or "the current application")
        steps = parsed.get("steps")
        if not isinstance(steps, list):
            return app_name, None
        cleaned = []
        for item in steps[:8]:
            if not isinstance(item, dict) or not item.get("target") or not item.get("instruction"):
                continue
            cleaned.append({
                "title": str(item.get("title") or f"Essential skill {len(cleaned) + 1}"),
                "target": str(item["target"]),
                "instruction": str(item["instruction"]),
                "expected_state": str(item.get("expected_state") or ""),
                "related_targets": item.get("related_targets", []),
            })
        return app_name, cleaned or None
    except Exception as error:
        print(f"[VisualTutor] Could not plan from the screen: {error}")
        return None, None


def _stop_progress_watch(state):
    with _STATE_LOCK:
        event = _WATCHERS.pop((state.get("lesson_id"), state.get("index")), None)
    if event is not None:
        event.set()


def _expected_state_for(state, index, step):
    expected = str(step.get("expected_state") or "").strip()
    if expected:
        return expected
    steps = state.get("steps", [])
    if index + 1 < len(steps):
        next_step = steps[index + 1]
        if isinstance(next_step, dict):
            return str(next_step.get("target") or next_step.get("element") or "").strip()
    return ""


def _start_progress_watch(state, index, step, player=None, speak=None, session_memory=None):
    expected = _expected_state_for(state, index, step)
    if not expected:
        return
    step = dict(step, expected_state=expected)
    initial_state = bool(_find_target(expected, player=player,
                                      session_memory=session_memory))
    event = threading.Event()
    lesson_id = state.get("lesson_id")
    _WATCHERS[(lesson_id, index)] = event
    threading.Thread(
        target=_watch_progress,
        args=(state, index, step, event, lesson_id, initial_state,
              player, speak, session_memory),
        name="nova-visual-progress", daemon=True,
    ).start()


def _watch_progress(state, index, step, event, lesson_id, initially_visible=False,
                    player=None, speak=None, session_memory=None):
    """Watch an active step for its requested visual completion state."""
    expected = str(step.get("expected_state") or "").strip()
    target = str(step.get("target") or step.get("element") or step.get("title") or "").strip()
    if not expected:
        return
    deadline = time.monotonic() + 180
    checks = 0
    seen_absent = not initially_visible
    while time.monotonic() < deadline and not event.wait(5.0):
        if not state.get("active") or state.get("lesson_id") != lesson_id or state.get("index") != index:
            return
        checks += 1
        # Follow a moving/resized control as the application layout changes.
        if checks % 2 == 0 and target:
            coords = _find_target(target, player=player, session_memory=session_memory)
            if coords:
                with _STATE_LOCK:
                    if state.get("lesson_id") == lesson_id and state.get("index") == index:
                        _highlight_at(coords[0], coords[1], f"Step {index + 1}: {step.get('title', target)}",
                                      bounds=coords[2:])
        expected_visible = bool(_find_target(expected, player=player, session_memory=session_memory))
        if not expected_visible:
            seen_absent = True
        if expected_visible and seen_absent:
            with _STATE_LOCK:
                if event.is_set() or state.get("lesson_id") != lesson_id or state.get("index") != index:
                    return
                _WATCHERS.pop((lesson_id, index), None)
                event.set()
                next_index = index + 1
                steps = state.get("steps", [])
                if next_index < len(steps):
                    # Reserve the next index before releasing the lock. A
                    # concurrent spoken "next" can then never be overwritten
                    # by a late automatic transition.
                    state["index"] = next_index
                    message = None
                else:
                    state["lesson_complete"] = True
                    if _clear_overlay:
                        _clear_overlay({})
                    message = "That lesson is complete. Visual Teaching Mode remains on for questions or another task."
            if player and hasattr(player, "write_log"):
                player.write_log(f"[VisualTutor] Detected completion of step {index + 1}")
            if message is None:
                message = _show_step(state, next_index, player=player, speak=speak,
                                     session_memory=session_memory)
            if speak and state.get("active"):
                try:
                    speak(message)
                except Exception:
                    pass
            return
    key = (lesson_id, index)
    if _WATCHERS.get(key) is event:
        _WATCHERS.pop(key, None)
        if state.get("active") and state.get("lesson_id") == lesson_id and state.get("index") == index:
            state["watch_timeout"] = True
            if _clear_overlay:
                _clear_overlay({})
            if player and hasattr(player, "write_log"):
                player.write_log(f"[VisualTutor] Progress watch timed out at step {index + 1}; highlight cleared")
            if speak:
                try:
                    speak("I’m still waiting for that screen change, so I’ve cleared the highlight. Say next when you want to continue.")
                except Exception:
                    pass


def _show_step(state, index, player=None, speak=None, session_memory=None):
    steps = state.get("steps", [])
    if not steps:
        return "There is no active visual lesson."
    index = max(0, min(index, len(steps) - 1))
    step = steps[index]
    title = str(step.get("title") or f"Step {index + 1}")
    instruction = str(step.get("instruction") or title)
    target = str(step.get("target") or step.get("element") or title)
    with _STATE_LOCK:
        _stop_progress_watch(state)
        state["index"] = index
        state["active"] = True
        lesson_id = state.get("lesson_id")
    coords = _find_target(target, player=player, session_memory=session_memory)
    if coords:
        related = []
        for item in step.get("related_targets", []):
            if isinstance(item, dict):
                description = str(item.get("target") or "")
                label = str(item.get("label") or description)
            else:
                description, label = str(item), str(item)
            if description:
                found = _find_target(description, player=player, session_memory=session_memory)
                if found:
                    related.append({"label": label, "coordinates": found})
    with _STATE_LOCK:
        # Ignore a slow screen lookup if a later step replaced this one while
        # the vision request was running.
        if state.get("lesson_id") != lesson_id or state.get("index") != index:
            return "The lesson has already moved to its newer step."
        if coords:
            overlay_result = _highlight_at(coords[0], coords[1], f"Step {index + 1}: {title}",
                                           bounds=coords[2:], related_targets=related)
        elif _clear_overlay:
            _clear_overlay({})
    _start_progress_watch(state, index, step, player=player, speak=speak,
                          session_memory=session_memory)
    if coords and not _overlay_available(overlay_result):
        return f"I found {target}, but the screen overlay could not be displayed ({overlay_result})."
    if not coords:
        return (f"Step {index + 1}: {instruction} I can’t confidently locate {target}, so I haven’t drawn a guessed highlight. "
                "I’ll still watch for the expected screen change.")
    return f"Step {index + 1} of {len(steps)}: {instruction} I’m watching the screen for the next change."


def visual_tutor(parameters: dict | None, player=None, speak=None, response=None, session_memory=None):
    """Handle explicit visual teaching requests and step navigation."""
    params = parameters or {}
    action = str(params.get("action") or "").lower().strip()
    state = _state_for(session_memory)
    text = str(params.get("text") or params.get("command") or params.get("query") or "").strip()
    lowered = text.lower()
    if not action:
        if any(x in lowered for x in ("stop teaching", "exit teaching", "end teaching", "stop visual")):
            action = "stop"
        elif any(x in lowered for x in ("turn on visual teaching", "enable visual teaching", "visual teaching mode on")):
            action = "enable"
        elif any(x in lowered for x in ("next step", "continue", "i did it", "done")):
            action = "next_step"
        elif any(x in lowered for x in ("teach", "show me how", "how do i", "how to")):
            action = "teach"
        elif "what does" in lowered or "what is this" in lowered:
            action = "what_is_this"
        elif "where" in lowered and ("click" in lowered or "change" in lowered):
            action = "where_click"
        else:
            action = "highlight"

    if action in ("stop", "end", "exit"):
        with _STATE_LOCK:
            _stop_progress_watch(state)
            if _clear_overlay:
                _clear_overlay({})
            state.clear()
        return "Visual Teaching Mode is off, and its screen highlight is cleared."

    if action in ("enable", "start_mode", "activate"):
        with _STATE_LOCK:
            _stop_progress_watch(state)
            state.clear()
            state["active"] = True
            state["steps"] = []
        return "Visual Teaching Mode is on. I’ll inspect the screen only when you ask for guidance."

    if action in ("teach", "teach_me", "teaching_mode", "show_how_to_use", "start"):
        task = str(params.get("task") or params.get("description") or text or "the current application")
        steps = params.get("steps")
        if not isinstance(steps, list) or not steps:
            app_name, planned_steps = _plan_essentials(task)
            if planned_steps:
                steps = planned_steps
                task = f"{app_name} beginner essentials"
            else:
                steps = _default_steps(app_name or task)
                task = f"{app_name or task} beginner essentials"
        with _STATE_LOCK:
            _stop_progress_watch(state)
            state.clear()
            state.update({"active": True, "task": task, "steps": steps, "index": 0,
                          "lesson_id": uuid.uuid4().hex})
        return _show_step(state, 0, player=player, session_memory=session_memory)

    if action in ("next_step", "next", "continue", "complete_step", "done_step"):
        with _STATE_LOCK:
            if not state.get("active"):
                return "Visual Teaching Mode is off. Ask me to teach you something to start it."
            next_index = int(state.get("index", 0)) + 1
            if next_index >= len(state.get("steps", [])):
                _stop_progress_watch(state)
                state["lesson_complete"] = True
                if _clear_overlay:
                    _clear_overlay({})
                return "That lesson is complete. Visual Teaching Mode remains on for questions or another task."
            _stop_progress_watch(state)
            state["index"] = next_index
        return _show_step(state, next_index, player=player, session_memory=session_memory)

    if action in ("what_is_this", "inspect", "where_click", "where_do_i_click", "highlight", "point", "annotate"):
        target = str(params.get("target") or params.get("description") or params.get("element") or text)
        if not target:
            return "Tell me which visible control you want me to identify."
        coords = _find_target(target, player=player, session_memory=session_memory)
        if not coords:
            return f"I can’t confidently locate {target} in the current screen view."
        label = "Click here" if action in ("where_click", "where_do_i_click") else str(params.get("label") or target)
        overlay_result = _highlight_at(coords[0], coords[1], label,
                                       duration=int(params.get("duration", 5000)), bounds=coords[2:])
        if not _overlay_available(overlay_result):
            return f"I found {target}, but the screen overlay could not be displayed ({overlay_result})."
        return f"I’ve highlighted {target}."

    if action in ("ask", "question"):
        if state.get("active"):
            return f"We’re on step {int(state.get('index', 0)) + 1} of the lesson about {state.get('task', 'this task')}. Answer the question using that context, then continue from this step."
        return "Visual Teaching Mode is off."
    return "Visual Teaching Mode is ready. Ask me to teach a task, identify a visible control, or stop the mode."


TOOL = {
    "name": "visual_tutor",
    "description": (
        "Opt-in visual teaching for NOVA. Start only when the user asks for visual teaching, screen guidance, "
        "or asks to identify a visible control. Captures the current screen only for that request, locates UI "
        "elements, draws an animated spotlight and NOVA pointer, and guides one step at a time. Keep the current "
        "lesson context for interruptions and questions. Never move the pointer, click, type, drag, or execute "
        "computer actions. For a teaching request, create ordered steps with a visible target, concise instruction, "
        "expected_state that becomes visible when completed, and optional related_targets. The tutor watches the "
        "screen only during an active lesson, follows moving targets, and advances when it detects the expected "
        "state. Never ask whether the user is ready or wants to continue. If the user says next, immediately "
        "replace the current overlay with the next step's target. "
        "Actions: enable, teach, highlight, what_is_this, where_click, next_step, stop."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "enable | teach | highlight | what_is_this | where_click | next_step | stop"},
            "target": {"type": "STRING", "description": "Visible interface element or region to locate"},
            "description": {"type": "STRING", "description": "Plain-language request or task"},
            "task": {"type": "STRING", "description": "Task the user wants to learn"},
            "steps": {"type": "ARRAY", "items": {"type": "OBJECT"}, "description": "Ordered steps with title, target, instruction, expected_state (visible only after completion), and optional related_targets"},
            "label": {"type": "STRING", "description": "Short overlay label"},
            "duration": {"type": "INTEGER", "description": "Highlight duration in milliseconds; zero keeps it visible"},
            "text": {"type": "STRING", "description": "Natural-language request"},
        },
        "required": [],
    },
    "handler": visual_tutor,
}
