"""
Energy dashboard action for JARVIS.
Track smart home device energy usage and costs.
Auto-discovered by core.action_loader.
"""
import json
import time
import sys
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict

try:
    from memory.memory_manager import load_memory, update_memory, save_memory
    _MEMORY = True
except ImportError:
    _MEMORY = False


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_BASE = _base_dir()
_CONFIG_PATH = _BASE / "config" / "api_keys.json"


def _load_config() -> dict:
    from memory.config_manager import load_api_keys
    return load_api_keys()


# Default device power ratings (watts)
DEFAULT_WATTAGE = {
    "fan": 35,           # Typical ceiling/fan
    "light": 10,         # LED bulb
    "ac": 1500,          # Air conditioner
    "tv": 100,           # LED TV
    "computer": 200,     # Desktop PC
    "heater": 1500,      # Space heater
    "fridge": 150,       # Refrigerator
    "washing_machine": 500,
    "microwave": 1000,
    "oven": 2000,
    "default": 50,
}

# Default electricity rate (₹/kWh)
DEFAULT_RATE = 7.5


def _get_device_config() -> dict:
    """Load device energy configuration from memory."""
    if not _MEMORY:
        return {}
    memory = load_memory()
    return memory.get("energy", {}).get("devices", {})


def _save_device_config(config: dict) -> None:
    """Save device energy configuration to memory."""
    if not _MEMORY:
        return
    update_memory({"energy": {"devices": config}})


def _get_usage_log() -> list:
    """Load usage log from memory."""
    if not _MEMORY:
        return []
    memory = load_memory()
    return memory.get("energy", {}).get("usage_log", [])


def _save_usage_log(log: list) -> None:
    """Save usage log to memory."""
    if not _MEMORY:
        return
    # Keep last 10000 entries
    update_memory({"energy": {"usage_log": log[-10000:]}})


def _record_state_change(device_id: str, device_name: str, device_type: str, is_on: bool, timestamp: float = None):
    """Record a device state change (on/off) in the usage log."""
    if timestamp is None:
        timestamp = time.time()

    log = _get_usage_log()
    log.append({
        "device_id": device_id,
        "device_name": device_name,
        "device_type": device_type,
        "is_on": is_on,
        "timestamp": timestamp,
        "date": datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d"),
    })
    _save_usage_log(log)


def _calculate_usage(device_id: str, days: int = 30) -> dict:
    """Calculate energy usage for a device over the last N days."""
    log = _get_usage_log()
    cutoff = time.time() - (days * 86400)

    device_log = [e for e in log if e["device_id"] == device_id and e["timestamp"] >= cutoff]

    if not device_log:
        return {"hours": 0, "kwh": 0, "cost": 0}

    # Sort by timestamp
    device_log.sort(key=lambda x: x["timestamp"])

    total_seconds = 0
    last_on_time = None

    for entry in device_log:
        if entry["is_on"]:
            last_on_time = entry["timestamp"]
        else:
            if last_on_time is not None:
                total_seconds += entry["timestamp"] - last_on_time
                last_on_time = None

    # If still on, count until now
    if last_on_time is not None:
        total_seconds += time.time() - last_on_time

    hours = total_seconds / 3600

    # Get wattage
    config = _get_device_config()
    device_config = config.get(device_id, {})
    wattage = device_config.get("wattage", DEFAULT_WATTAGE.get(device_config.get("type", "default"), DEFAULT_WATTAGE["default"]))

    kwh = (wattage * hours) / 1000
    rate = device_config.get("rate", DEFAULT_RATE)
    cost = kwh * rate

    return {
        "hours": round(hours, 2),
        "kwh": round(kwh, 3),
        "cost": round(cost, 2),
        "wattage": wattage,
        "rate": rate,
    }


def _get_all_devices_usage(days: int = 30) -> dict:
    """Get usage for all known devices."""
    log = _get_usage_log()
    if not log:
        return {}

    device_ids = set(e["device_id"] for e in log)
    result = {}
    for did in device_ids:
        usage = _calculate_usage(did, days)
        if usage["hours"] > 0:
            device_info = next((e for e in log if e["device_id"] == did), {})
            result[did] = {
                "name": device_info.get("device_name", did),
                "type": device_info.get("device_type", "unknown"),
                **usage
            }
    return result


def run(parameters: dict, player=None, speak=None, response=None, session_memory=None) -> str:
    """
    Energy dashboard commands.

    Parameters:
    - action: "report" | "set_rate" | "set_wattage" | "device_on" | "device_off" | "summary" | "monthly"
    - device_id: device identifier
    - device_name: friendly name
    - device_type: fan, light, ac, tv, etc.
    - rate: ₹/kWh
    - wattage: watts
    - days: number of days for report (default 30)
    """
    if not _MEMORY:
        return "Memory module not available"

    action = parameters.get("action", "report")

    if action == "device_on":
        # Called when a device is turned on
        device_id = parameters.get("device_id")
        device_name = parameters.get("device_name", device_id)
        device_type = parameters.get("device_type", "default")
        if not device_id:
            return "device_id required"
        _record_state_change(device_id, device_name, device_type, True)
        return f"Recorded {device_name} turned ON"

    elif action == "device_off":
        # Called when a device is turned off
        device_id = parameters.get("device_id")
        device_name = parameters.get("device_name", device_id)
        device_type = parameters.get("device_type", "default")
        if not device_id:
            return "device_id required"
        _record_state_change(device_id, device_name, device_type, False)
        return f"Recorded {device_name} turned OFF"

    elif action == "set_wattage":
        device_id = parameters.get("device_id")
        wattage = parameters.get("wattage")
        device_type = parameters.get("device_type", "default")
        if not device_id or wattage is None:
            return "device_id and wattage required"
        config = _get_device_config()
        config[device_id] = {
            "wattage": float(wattage),
            "type": device_type,
            "rate": config.get(device_id, {}).get("rate", DEFAULT_RATE),
        }
        _save_device_config(config)
        return f"Set {device_id} wattage to {wattage}W ({device_type})"

    elif action == "set_rate":
        device_id = parameters.get("device_id")
        rate = parameters.get("rate")
        if not device_id or rate is None:
            return "device_id and rate required"
        config = _get_device_config()
        if device_id not in config:
            config[device_id] = {"wattage": DEFAULT_WATTAGE.get("default", 50), "type": "default"}
        config[device_id]["rate"] = float(rate)
        _save_device_config(config)
        return f"Set {device_id} rate to ₹{rate}/kWh"

    elif action == "summary":
        # Quick summary of all devices
        days = parameters.get("days", 7)
        usage = _get_all_devices_usage(days)
        if not usage:
            return f"No energy data for the last {days} days."

        total_kwh = sum(u["kwh"] for u in usage.values())
        total_cost = sum(u["cost"] for u in usage.values())

        lines = [f"⚡ ENERGY SUMMARY (last {days} days)", f"Total: {total_kwh:.2f} kWh  •  ₹{total_cost:.2f}", ""]
        for did, u in sorted(usage.items(), key=lambda x: x[1]["cost"], reverse=True):
            lines.append(f"  {u['name']} ({u['type']}): {u['hours']:.1f}h  {u['kwh']:.2f} kWh  ₹{u['cost']:.2f}")

        if player and hasattr(player, 'show_content'):
            player.show_content(f"ENERGY ({days}d)", "\n".join(lines))

        return "\n".join(lines)

    elif action == "monthly":
        # Monthly report
        usage = _get_all_devices_usage(30)
        if not usage:
            return "No energy data for the last 30 days."

        total_kwh = sum(u["kwh"] for u in usage.values())
        total_cost = sum(u["cost"] for u in usage.values())

        # Project to monthly
        now = datetime.now()
        days_elapsed = now.day + (now.hour / 24)
        if days_elapsed > 0:
            projected_kwh = total_kwh * (30 / days_elapsed)
            projected_cost = total_cost * (30 / days_elapsed)
        else:
            projected_kwh = total_kwh
            projected_cost = total_cost

        lines = [
            f"📊 MONTHLY ENERGY REPORT ({now.strftime('%B %Y')})",
            f"Projected: {projected_kwh:.1f} kWh  •  ₹{projected_cost:.2f}",
            f"So far: {total_kwh:.2f} kWh  •  ₹{total_cost:.2f}",
            ""
        ]
        for did, u in sorted(usage.items(), key=lambda x: x[1]["cost"], reverse=True):
            lines.append(f"  {u['name']} ({u['type']}): {u['hours']:.1f}h  {u['kwh']:.2f} kWh  ₹{u['cost']:.2f}")

        if player and hasattr(player, 'show_content'):
            player.show_content("MONTHLY ENERGY", "\n".join(lines))

        return "\n".join(lines)

    elif action == "device_report":
        # Single device detail
        device_id = parameters.get("device_id")
        days = parameters.get("days", 30)
        if not device_id:
            return "device_id required"
        usage = _calculate_usage(device_id, days)
        if usage["hours"] == 0:
            return f"No usage data for device {device_id}"

        config = _get_device_config()
        dev_config = config.get(device_id, {})
        name = dev_config.get("name", device_id)

        lines = [
            f"⚡ {name} ({device_id})",
            f"  Type: {dev_config.get('type', 'unknown')}",
            f"  Wattage: {usage['wattage']}W",
            f"  Rate: ₹{usage['rate']}/kWh",
            f"  Last {days} days:",
            f"    Runtime: {usage['hours']:.1f} hours",
            f"    Energy: {usage['kwh']:.3f} kWh",
            f"    Cost: ₹{usage['cost']:.2f}",
        ]

        if player and hasattr(player, 'show_content'):
            player.show_content(f"ENERGY: {name}", "\n".join(lines))

        return "\n".join(lines)

    elif action == "list":
        # List configured devices
        config = _get_device_config()
        if not config:
            return "No devices configured. Use set_wattage to add."
        lines = ["Configured devices:"]
        for did, cfg in config.items():
            lines.append(f"  {did}: {cfg.get('wattage', '?')}W ({cfg.get('type', '?')}) @ ₹{cfg.get('rate', DEFAULT_RATE)}/kWh")
        return "\n".join(lines)

    else:
        # Default: weekly report
        return run({"action": "summary", "days": 7}, player, speak, response, session_memory)


# Hook for smart_home_control to auto-record state changes
def hook_device_action(device_id: str, device_name: str, device_type: str, is_on: bool):
    """Call this from smart_home_control after executing a command."""
    _record_state_change(device_id, device_name, device_type, is_on)


TOOL = {
    "name": "energy_dashboard",
    "description": (
        "Track and report energy usage and costs for smart home devices. "
        "Records device on/off events, calculates kWh and cost based on wattage and electricity rate. "
        "Provides daily, weekly, and monthly reports. "
        "Configure device wattage and rate with set_wattage/set_rate. "
        "Smart home actions should call device_on/device_off to auto-track."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "report | monthly | device_report | set_wattage | set_rate | device_on | device_off | list"
            },
            "device_id": {
                "type": "STRING",
                "description": "Device identifier (from smart home)"
            },
            "device_name": {
                "type": "STRING",
                "description": "Friendly device name"
            },
            "device_type": {
                "type": "STRING",
                "description": "Device type: fan, light, ac, tv, computer, heater, fridge, default"
            },
            "wattage": {
                "type": "NUMBER",
                "description": "Power consumption in watts"
            },
            "rate": {
                "type": "NUMBER",
                "description": "Electricity rate in ₹/kWh"
            },
            "days": {
                "type": "INTEGER",
                "description": "Days to include in report (default 7 for summary, 30 for monthly)"
            }
        },
        "required": []
    },
    "handler": run,
}