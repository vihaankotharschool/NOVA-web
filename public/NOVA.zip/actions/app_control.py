"""
App-specific command action for JARVIS.
Execute keystrokes/commands scoped to the currently focused application.
Auto-discovered by core.action_loader.
"""
import json
import copy
import platform
import time
import sys
from pathlib import Path

try:
    import pyautogui
    import pygetwindow as gw
    _PYAUTO = True
except ImportError:
    _PYAUTO = False


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_BASE = _base_dir()
_CONFIG_PATH = _BASE / "config" / "api_keys.json"
_APP_MAP_PATH = _BASE / "config" / "app_keymaps.json"
_SESSION_APP_KEYMAPS: dict | None = None


def _load_config() -> dict:
    from memory.config_manager import load_api_keys
    return load_api_keys()


def _load_app_keymaps() -> dict:
    """Load defaults and current-run app keymaps without disk persistence."""
    global _SESSION_APP_KEYMAPS
    if _SESSION_APP_KEYMAPS is None:
        _SESSION_APP_KEYMAPS = copy.deepcopy(DEFAULT_KEYMAPS)
    return copy.deepcopy(_SESSION_APP_KEYMAPS)


def _save_app_keymaps(keymaps: dict) -> None:
    """Keep learned app keymaps in memory for this run only."""
    global _SESSION_APP_KEYMAPS
    _SESSION_APP_KEYMAPS = copy.deepcopy(keymaps)


def _get_active_window_info() -> dict:
    """Get info about the currently active window."""
    if not _PYAUTO:
        return {"title": "", "exe": "", "pid": 0}
    try:
        win = gw.getActiveWindow()
        if win:
            return {
                "title": win.title or "",
                "exe": _guess_exe_from_title(win.title),
                "pid": getattr(win, '_hWnd', 0) if platform.system() == "Windows" else 0
            }
    except Exception:
        pass
    return {"title": "", "exe": "", "pid": 0}


def _guess_exe_from_title(title: str) -> str:
    """Guess executable name from window title."""
    title_lower = title.lower()
    exe_map = {
        "chrome": "chrome.exe",
        "firefox": "firefox.exe",
        "edge": "msedge.exe",
        "brave": "brave.exe",
        "vscode": "code.exe",
        "visual studio code": "code.exe",
        "pycharm": "pycharm64.exe",
        "intellij": "idea64.exe",
        "terminal": "wt.exe",
        "cmd": "cmd.exe",
        "powershell": "powershell.exe",
        "discord": "discord.exe",
        "slack": "slack.exe",
        "spotify": "spotify.exe",
        "notepad": "notepad.exe",
        "explorer": "explorer.exe",
    }
    for key, exe in exe_map.items():
        if key in title_lower:
            return exe
    return ""


def _match_app(keymaps: dict, window_info: dict) -> str | None:
    """Match active window to a known app keymap."""
    title = window_info.get("title", "").lower()
    exe = window_info.get("exe", "").lower()

    # Direct exe match
    for app_name, config in keymaps.items():
        if config.get("exe", "").lower() == exe:
            return app_name

    # Title keyword match
    for app_name, config in keymaps.items():
        for keyword in config.get("title_keywords", []):
            if keyword.lower() in title:
                return app_name

    return None


def _execute_keystrokes(keys: list | str, interval: float = 0.05) -> bool:
    """Execute a sequence of keystrokes."""
    if not _PYAUTO:
        return False
    try:
        if isinstance(keys, str):
            # Parse string like "ctrl+shift+p" or "ctrl+c, enter"
            parts = [p.strip() for p in keys.split(",")]
            for part in parts:
                if "+" in part:
                    keys_list = part.split("+")
                    pyautogui.hotkey(*keys_list)
                else:
                    pyautogui.press(part)
                time.sleep(interval)
        elif isinstance(keys, list):
            for key in keys:
                if isinstance(key, list):
                    pyautogui.hotkey(*key)
                else:
                    pyautogui.press(key)
                time.sleep(interval)
        return True
    except Exception as e:
        print(f"[AppControl] Keystroke error: {e}")
        return False


def run(parameters: dict, player=None, speak=None, response=None, session_memory=None) -> str:
    """
    Execute app-specific command.

    Parameters:
    - command: name of predefined command (e.g., "close_tab", "run_tests", "save")
    - app: optional app name to target (defaults to active window)
    - keys: raw keystroke sequence to execute (alternative to predefined command)
    - list_commands: true to list available commands for current/any app
    - teach: {app: "name", command: "name", keys: "ctrl+s"} to add new mapping
    """
    if not _PYAUTO:
        return "pyautogui/pygetwindow not installed. Run: pip install pyautogui pygetwindow"

    keymaps = _load_app_keymaps()
    window_info = _get_active_window_info()
    active_app = _match_app(keymaps, window_info)

    # List commands
    if parameters.get("list_commands"):
        target_app = parameters.get("app") or active_app
        if target_app and target_app in keymaps:
            cmds = keymaps[target_app].get("commands", {})
            return f"Commands for {target_app}: {', '.join(cmds.keys())}"
        else:
            all_cmds = {}
            for app, config in keymaps.items():
                for cmd, keys in config.get("commands", {}).items():
                    all_cmds[f"{app}.{cmd}"] = keys
            return "All known commands:\n" + "\n".join(f"  {k}: {v}" for k, v in all_cmds.items())

    # Teach new command
    if "teach" in parameters:
        teach = parameters["teach"]
        app_name = teach.get("app")
        cmd_name = teach.get("command")
        keys = teach.get("keys")
        if not all([app_name, cmd_name, keys]):
            return "Teach requires app, command, and keys"
        if app_name not in keymaps:
            keymaps[app_name] = {"exe": "", "title_keywords": [], "commands": {}}
        keymaps[app_name]["commands"][cmd_name] = keys
        _save_app_keymaps(keymaps)
        return f"Taught {app_name}.{cmd_name} = {keys}"

    # Determine target app
    target_app = parameters.get("app") or active_app
    if not target_app:
        return f"No app specified and couldn't detect active window. Active: {window_info.get('title', 'unknown')}"

    if target_app not in keymaps:
        return f"Unknown app: {target_app}. Known: {', '.join(keymaps.keys())}"

    app_config = keymaps[target_app]
    commands = app_config.get("commands", {})

    # Execute predefined command
    command = parameters.get("command")
    if command:
        if command not in commands:
            return f"Unknown command '{command}' for {target_app}. Available: {', '.join(commands.keys())}"
        keys = commands[command]
        if _execute_keystrokes(keys):
            if player and hasattr(player, 'write_log'):
                player.write_log(f"[AppControl] {target_app}.{command} -> {keys}")
            return f"Executed {command} in {target_app}"
        return f"Failed to execute {command} in {target_app}"

    # Execute raw keys
    keys = parameters.get("keys")
    if keys:
        if _execute_keystrokes(keys):
            if player and hasattr(player, 'write_log'):
                player.write_log(f"[AppControl] Raw keys in {target_app}: {keys}")
            return f"Executed raw keys in {target_app}"
        return f"Failed to execute raw keys in {target_app}"

    return "Specify a command, keys, list_commands, or teach"


# Default keymaps (used if config file doesn't exist)
DEFAULT_KEYMAPS = {
    "chrome": {
        "exe": "chrome.exe",
        "title_keywords": ["chrome", "google chrome"],
        "commands": {
            "close_tab": "ctrl+w",
            "new_tab": "ctrl+t",
            "reopen_tab": "ctrl+shift+t",
            "next_tab": "ctrl+tab",
            "prev_tab": "ctrl+shift+tab",
            "address_bar": "ctrl+l",
            "refresh": "f5",
            "hard_refresh": "ctrl+shift+r",
            "devtools": "f12",
            "find": "ctrl+f",
            "zoom_in": "ctrl+=",
            "zoom_out": "ctrl+-",
            "zoom_reset": "ctrl+0",
            "history": "ctrl+h",
            "downloads": "ctrl+j",
            "bookmarks": "ctrl+shift+o",
        }
    },
    "firefox": {
        "exe": "firefox.exe",
        "title_keywords": ["firefox", "mozilla firefox"],
        "commands": {
            "close_tab": "ctrl+w",
            "new_tab": "ctrl+t",
            "reopen_tab": "ctrl+shift+t",
            "next_tab": "ctrl+tab",
            "prev_tab": "ctrl+shift+tab",
            "address_bar": "ctrl+l",
            "refresh": "f5",
            "devtools": "f12",
        }
    },
    "edge": {
        "exe": "msedge.exe",
        "title_keywords": ["edge", "microsoft edge"],
        "commands": {
            "close_tab": "ctrl+w",
            "new_tab": "ctrl+t",
            "reopen_tab": "ctrl+shift+t",
            "address_bar": "ctrl+l",
            "refresh": "f5",
            "devtools": "f12",
        }
    },
    "vscode": {
        "exe": "code.exe",
        "title_keywords": ["visual studio code", "vscode", "code - "],
        "commands": {
            "save": "ctrl+s",
            "save_all": "ctrl+k s",
            "toggle_terminal": "ctrl+`",
            "command_palette": "ctrl+shift+p",
            "quick_open": "ctrl+p",
            "toggle_sidebar": "ctrl+b",
            "toggle_panel": "ctrl+j",
            "run": "f5",
            "debug": "f9",
            "format": "shift+alt+f",
            "comment": "ctrl+/",
            "duplicate_line": "shift+alt+down",
            "delete_line": "ctrl+shift+k",
            "multi_cursor": "ctrl+alt+down",
            "go_to_line": "ctrl+g",
            "rename": "f2",
            "peek": "alt+f12",
            "search": "ctrl+shift+f",
            "replace": "ctrl+h",
        }
    },
    "pycharm": {
        "exe": "pycharm64.exe",
        "title_keywords": ["pycharm"],
        "commands": {
            "run": "shift+f10",
            "debug": "shift+f9",
            "save_all": "ctrl+shift+s",
            "reformat": "ctrl+alt+l",
            "optimize_imports": "ctrl+alt+o",
            "commit": "ctrl+k",
            "push": "ctrl+shift+k",
        }
    },
    "terminal": {
        "exe": "wt.exe",
        "title_keywords": ["windows terminal", "terminal", "powershell", "command prompt"],
        "commands": {
            "clear": "cls, enter",
            "new_tab": "ctrl+shift+t",
            "close_tab": "ctrl+shift+w",
            "split_pane": "alt+shift+d",
            "copy": "ctrl+shift+c",
            "paste": "ctrl+shift+v",
        }
    },
    "discord": {
        "exe": "discord.exe",
        "title_keywords": ["discord"],
        "commands": {
            "mute": "ctrl+shift+m",
            "deafen": "ctrl+shift+d",
            "reply": "r",
            "search": "ctrl+f",
            "dm_list": "ctrl+shift+i",
            "server_list": "ctrl+shift+e",
        }
    },
    "spotify": {
        "exe": "spotify.exe",
        "title_keywords": ["spotify"],
        "commands": {
            "play_pause": "space",
            "next": "ctrl+right",
            "previous": "ctrl+left",
            "volume_up": "ctrl+up",
            "volume_down": "ctrl+down",
            "shuffle": "ctrl+s",
            "repeat": "ctrl+r",
            "like": "ctrl+shift+.",
            "search": "ctrl+l",
        }
    },
    "notepad": {
        "exe": "notepad.exe",
        "title_keywords": ["notepad"],
        "commands": {
            "save": "ctrl+s",
            "save_as": "ctrl+shift+s",
            "find": "ctrl+f",
            "replace": "ctrl+h",
            "select_all": "ctrl+a",
            "word_wrap": "alt+v, w",
        }
    },
    "explorer": {
        "exe": "explorer.exe",
        "title_keywords": ["file explorer", "explorer", "this pc", "quick access"],
        "commands": {
            "new_folder": "ctrl+shift+n",
            "refresh": "f5",
            "address_bar": "ctrl+l",
            "search": "ctrl+f",
            "select_all": "ctrl+a",
            "properties": "alt+enter",
        }
    },
}


def _ensure_default_keymaps():
    """Initialize default app keymaps in memory only."""
    _load_app_keymaps()


# Initialize defaults on import
_ensure_default_keymaps()


TOOL = {
    "name": "app_control",
    "description": (
        "Execute application-specific keystrokes and commands. "
        "Automatically detects the active window and maps commands like 'close tab', "
        "'run tests', 'save', 'mute' to the correct keystrokes for that app. "
        "Supports Chrome, Firefox, Edge, VS Code, PyCharm, Terminal, Discord, Spotify, Notepad, Explorer. "
        "Can teach new commands: teach={{app: 'chrome', command: 'my_cmd', keys: 'ctrl+shift+x'}}"
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "command": {
                "type": "STRING",
                "description": "Predefined command name (close_tab, run_tests, save, mute, etc.)"
            },
            "app": {
                "type": "STRING",
                "description": "Target app name (chrome, vscode, terminal, discord, spotify, etc.). Defaults to active window."
            },
            "keys": {
                "type": "STRING",
                "description": "Raw keystroke sequence (e.g., 'ctrl+shift+p, enter' or 'ctrl+c, ctrl+v')"
            },
            "list_commands": {
                "type": "BOOLEAN",
                "description": "List available commands for current or specified app"
            },
            "teach": {
                "type": "OBJECT",
                "description": "Teach a new command: {app, command, keys}",
                "properties": {
                    "app": {"type": "STRING"},
                    "command": {"type": "STRING"},
                    "keys": {"type": "STRING"}
                }
            }
        },
        "required": []
    },
    "handler": run,
}