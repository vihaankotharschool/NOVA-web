"""NOVA smart-home action. Auto-discovered by core.action_loader."""
from smart_home.service import SmartHomeService

_service = SmartHomeService()

# Import energy dashboard hook
try:
    from actions.energy_dashboard import hook_device_action
    _ENERGY_AVAILABLE = True
except ImportError:
    _ENERGY_AVAILABLE = False
    def hook_device_action(device_id, device_name, device_type, is_on):
        pass


def _run_smart_home(parameters, context=None):
    command = str((parameters or {}).get("command") or "").strip()
    if not command:
        return "Please provide a smart-home command."
    result = _service.execute_command(command)

    # Auto-track energy usage for on/off commands
    if _ENERGY_AVAILABLE and result:
        detail = str(result.get("detail", "")).lower()
        targets = result.get("targets", [])
        action = result.get("action", "")

        if action == "power" and targets:
            is_on = "on" in detail or "turned on" in detail
            for target in targets:
                # Find device in service to get ID and type
                devices = _service.list_devices()
                for dev in devices:
                    if dev.get("name") == target or dev.get("id") == target:
                        hook_device_action(
                            str(dev.get("id", "")),
                            dev.get("name", target),
                            dev.get("device_type", "default"),
                            is_on
                        )
                        break

    return str(result.get("detail") or "Smart-home command completed.")

TOOL = {
    "name": "smart_home_control",
    "description": (
        "Controls connected smart-home devices. Use for fans, lights, plugs, switches, "
        "air conditioners, and other devices. Commands can be natural language, such as "
        "'turn on the fan', 'turn off the bedroom light', 'set the fan speed to 4', "
        "'set brightness to 70', or 'turn everything off'. Always use this tool for a "
        "connected physical home device instead of claiming the action was completed."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "command": {"type": "STRING", "description": "The user's smart-home command in natural language."}
        },
        "required": ["command"],
    },
    "handler": _run_smart_home,
}
