import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import unittest

from PyQt6.QtGui import QImage, QPainter
from PyQt6.QtWidgets import QApplication

from actions import screen_annotate as annotations
from actions.screen_annotate import AnnotationOverlay, _to_overlay_coordinates


class ScreenOverlayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_annotations_translate_from_desktop_to_overlay_coordinates(self):
        annotations = [{"type": "pointer", "pt1": [120, 230], "pt2": [180, 230]},
                       {"type": "number", "center": [120, 210]}]
        converted = _to_overlay_coordinates(annotations, 100, 200)
        self.assertEqual(converted[0]["pt1"], [20, 30])
        self.assertEqual(converted[0]["pt2"], [80, 30])
        self.assertEqual(converted[1]["center"], [20, 10])

    def test_spotlight_leaves_target_interior_clear_and_paints_attention_cues(self):
        overlay = AnnotationOverlay()
        overlay.resize(200, 140)
        image = QImage(200, 140, QImage.Format.Format_ARGB32)
        image.fill(0)
        painter = QPainter(image)
        target = {"pt1": [45, 40], "pt2": [95, 75]}
        overlay._draw_annotation(painter, {"type": "spotlight", **target})
        overlay._draw_annotation(painter, {"type": "glow", **target})
        overlay._draw_annotation(painter, {"type": "pointer", "pt1": [20, 58],
                                           "pt2": [39, 58]})
        overlay._draw_annotation(painter, {"type": "number", "center": [38, 34],
                                           "value": "2"})
        painter.end()

        self.assertEqual(image.pixelColor(70, 58).alpha(), 0)
        self.assertGreater(image.pixelColor(10, 10).alpha(), 0)
        self.assertGreater(image.pixelColor(38, 34).alpha(), 0)
        overlay._pulse_timer.stop()
        overlay.close()

    def test_overlay_dispatch_confirms_a_visible_window(self):
        result = annotations._run_overlay([
            {"type": "glow", "pt1": [25, 25], "pt2": [100, 80]},
        ], duration=0)
        self.app.processEvents()
        self.assertIn("Overlay shown", result)
        self.assertTrue(annotations._get_overlay().isVisible())
        annotations.clear_overlay({})
        self.app.processEvents()


if __name__ == "__main__":
    unittest.main()
