import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from memory import config_manager, memory_manager
from smart_home.storage import SmartHomeStorage


class NoPersistentUserDataTests(unittest.TestCase):
    def test_api_key_and_settings_stay_in_memory(self):
        with tempfile.TemporaryDirectory() as tmp, \
                patch.object(config_manager, "CONFIG_FILE", Path(tmp) / "api_keys.json"), \
                patch.dict(config_manager._SESSION_CONFIG, {}, clear=True):
            config_manager.save_api_keys("test-api-key")
            config_manager.save_session_config({"user_name": "temporary"})

            self.assertEqual(config_manager.get_gemini_key(), "test-api-key")
            self.assertEqual(config_manager.get_user_name(), "temporary")
            self.assertFalse(config_manager.CONFIG_FILE.exists())

    def test_memory_and_session_summaries_are_not_written(self):
        with tempfile.TemporaryDirectory() as tmp, \
                patch.object(memory_manager, "MEMORY_PATH", Path(tmp) / "memory.json"):
            memory_manager.update_memory({"identity": {"name": "temporary"}})
            memory_manager.save_memory({"identity": {"name": "temporary"}})
            memory_manager.save_session_summary("temporary conversation")

            self.assertEqual(memory_manager.load_memory()["identity"], {})
            self.assertIsNone(memory_manager.pop_last_session())
            self.assertFalse(memory_manager.MEMORY_PATH.exists())

    def test_smart_home_credentials_are_process_local(self):
        with tempfile.TemporaryDirectory() as tmp:
            storage = SmartHomeStorage(Path(tmp) / "smart_home.json")
            account_id = storage.save_provider_account(
                "provider", "Temporary", {"api_key": "secret"}
            )

            account = storage.get_provider_account(account_id)
            self.assertEqual(account["credentials"]["api_key"], "secret")
            self.assertFalse(storage.path.exists())

    def test_startup_cleanup_removes_legacy_user_files_and_runtime_values(self):
        with tempfile.TemporaryDirectory() as tmp, \
                patch.object(config_manager, "BASE_DIR", Path(tmp)), \
                patch.object(config_manager, "CONFIG_DIR", Path(tmp) / "config"), \
                patch.object(config_manager, "CONFIG_FILE", Path(tmp) / "config" / "api_keys.json"), \
                patch.dict(config_manager._SESSION_CONFIG, {"gemini_api_key": "temporary"}, clear=True):
            paths = (
                config_manager.CONFIG_FILE,
                Path(tmp) / "memory" / "long_term.json",
                config_manager.CONFIG_DIR / "smart_home.json",
                config_manager.CONFIG_DIR / "app_keymaps.json",
            )
            for path in paths:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("legacy user data", encoding="utf-8")

            config_manager.clear_saved_user_data()

            self.assertEqual(config_manager.load_api_keys(), {})
            self.assertTrue(all(not path.exists() for path in paths))


if __name__ == "__main__":
    unittest.main()
