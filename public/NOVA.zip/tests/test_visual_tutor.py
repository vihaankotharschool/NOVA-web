import json
import threading
import unittest
from unittest.mock import Mock, patch

from actions import visual_tutor as tutor


class VisualTutorTests(unittest.TestCase):
    def setUp(self):
        self.state = {}

    def test_start_teaching_highlights_first_step_without_computer_input(self):
        steps = [{"title": "Open File", "target": "File menu",
                  "instruction": "Open the File menu.",
                  "expected_state": "File menu is open"}]
        with patch.object(tutor, "_find_target", return_value=(100, 100, 80, 80, 120, 120)), \
             patch.object(tutor, "_highlight_at", return_value="Overlay shown with 4 annotation(s)") as highlight, \
             patch.object(tutor.threading, "Thread") as worker, \
             patch.object(tutor, "_computer_control") as computer:
            result = tutor.visual_tutor({"action": "teach", "task": "Export this file", "steps": steps},
                                        session_memory=self.state)

        self.assertIn("Step 1 of 1", result)
        self.assertNotIn("ready", result.lower())
        self.assertTrue(self.state["visual_tutor_state"]["active"])
        highlight.assert_called_once()
        worker.return_value.start.assert_called_once()
        computer.assert_not_called()

    def test_generic_teach_request_starts_a_prepared_app_essentials_tour(self):
        steps = [
            {"title": "Workspace", "target": "Blender 3D viewport", "instruction": "Explore the viewport."},
            {"title": "Move an object", "target": "Blender move tool", "instruction": "Move the selected object."},
            {"title": "Save", "target": "Blender save command", "instruction": "Save the project."},
        ]
        with patch.object(tutor, "_plan_essentials", return_value=("Blender", steps)), \
             patch.object(tutor, "_find_target", return_value=(100, 100, 80, 80, 120, 120)), \
             patch.object(tutor, "_highlight_at", return_value="Overlay shown with 4 annotation(s)"), \
             patch.object(tutor.threading, "Thread"):
            result = tutor.visual_tutor({"action": "teach", "task": "Teach me"},
                                        session_memory=self.state)
        state = self.state["visual_tutor_state"]
        self.assertIn("Step 1 of 3", result)
        self.assertIn("Blender beginner essentials", state["task"])
        self.assertEqual(len(state["steps"]), 3)
        self.assertNotIn("what would you like to learn", result.lower())

    def test_expected_screen_state_advances_lesson_automatically(self):
        state = {
            "active": True,
            "task": "Export a project",
            "index": 0,
            "lesson_id": "lesson-a",
            "steps": [
                {"title": "Open File", "target": "File menu",
                 "instruction": "Open File.", "expected_state": "File menu is open"},
                {"title": "Choose Export", "target": "Export menu item",
                 "instruction": "Choose Export."},
            ],
        }
        event = threading.Event()
        spoken = []
        location = (100, 100, 80, 80, 120, 120)
        with patch.object(tutor, "_find_target", return_value=location), \
             patch.object(tutor, "_highlight_at", return_value="Overlay shown with 4 annotation(s)"), \
             patch.object(tutor.threading, "Thread"):
            tutor._watch_progress(state, 0, state["steps"][0], event,
                                  "lesson-a", speak=spoken.append)

        self.assertEqual(state["index"], 1)
        self.assertEqual(state["steps"][1]["title"], "Choose Export")
        self.assertTrue(spoken)
        self.assertIn("Step 2", spoken[0])

    def test_next_step_target_is_used_as_a_fallback_progress_signal(self):
        state = {"steps": [{"target": "File menu"}, {"target": "Export menu item"}]}
        self.assertEqual(tutor._expected_state_for(state, 0, state["steps"][0]),
                         "Export menu item")

    def test_progress_watcher_stops_when_lesson_is_cancelled(self):
        state = {"active": False, "lesson_id": "lesson-a", "index": 0,
                 "steps": [{"target": "File", "expected_state": "File open"}]}
        event = threading.Event()
        with patch.object(tutor, "_find_target") as find:
            tutor._watch_progress(state, 0, state["steps"][0], event, "lesson-a")
        find.assert_not_called()

    def test_already_visible_expected_state_must_change_before_advancing(self):
        state = {"active": True, "index": 0, "lesson_id": "lesson-b", "steps": [
            {"title": "Open File", "target": "File menu",
             "expected_state": "File menu is open"},
            {"title": "Choose Export", "target": "Export menu item"},
        ]}
        event = Mock()
        event.wait.side_effect = [False, True]
        location = (100, 100, 80, 80, 120, 120)
        with patch.object(tutor, "_find_target", return_value=location) as find:
            tutor._watch_progress(state, 0, state["steps"][0], event,
                                  "lesson-b", initially_visible=True)
        self.assertEqual(state["index"], 0)
        self.assertEqual(find.call_count, 1)

    def test_expected_state_must_disappear_then_reappear_if_present_at_start(self):
        state = {"active": True, "index": 0, "lesson_id": "lesson-c", "steps": [
            {"title": "Open File", "target": "File menu",
             "expected_state": "File menu is open"},
            {"title": "Choose Export", "target": "Export menu item"},
        ]}
        event = Mock()
        event.wait.side_effect = [False, False, False]
        event.is_set.return_value = False
        location = (100, 100, 80, 80, 120, 120)
        with patch.object(tutor, "_find_target", side_effect=[location, location, None, location, location]), \
             patch.object(tutor, "_highlight_at", return_value="Overlay shown with 4 annotation(s)"), \
             patch.object(tutor.threading, "Thread"):
            tutor._watch_progress(state, 0, state["steps"][0], event,
                                  "lesson-c", initially_visible=True)
        self.assertEqual(state["index"], 1)

    def test_user_input_is_not_used_for_highlight_requests(self):
        result = json.dumps({"x": 100, "y": 100, "left": 80, "top": 80,
                             "right": 120, "bottom": 120})
        with patch.object(tutor, "_computer_control", return_value=result) as computer, \
             patch.object(tutor, "_highlight_at"):
            tutor.visual_tutor({"action": "where_click", "target": "Export button"},
                               session_memory=self.state)

        self.assertEqual(computer.call_count, 1)
        self.assertEqual(computer.call_args.args[0]["action"], "screen_find")

    def test_saying_next_replaces_the_overlay_with_the_next_target(self):
        self.state["visual_tutor_state"] = {
            "active": True,
            "task": "Export a file",
            "index": 0,
            "lesson_id": "lesson-next",
            "steps": [
                {"title": "Open File", "target": "File menu", "instruction": "Open File."},
                {"title": "Choose Export", "target": "Export menu item", "instruction": "Choose Export."},
            ],
        }
        def locate(query, **kwargs):
            x = 320 if "export" in query.lower() else 100
            return (x, 100, x - 20, 80, x + 20, 120)
        with patch.object(tutor, "_find_target", side_effect=locate), \
             patch.object(tutor, "_highlight_at", return_value="Overlay shown with 4 annotation(s)") as highlight, \
             patch.object(tutor.threading, "Thread"):
            result = tutor.visual_tutor({"action": "next_step"}, session_memory=self.state)

        self.assertEqual(self.state["visual_tutor_state"]["index"], 1)
        self.assertIn("Step 2", result)
        self.assertEqual(highlight.call_args.args[:3], (320, 100, "Step 2: Choose Export"))

    def test_tutor_does_not_claim_success_when_overlay_is_unavailable(self):
        with patch.object(tutor, "_find_target", return_value=(100, 100, 80, 80, 120, 120)), \
             patch.object(tutor, "_highlight_at", return_value="No Qt application running"):
            result = tutor.visual_tutor({"action": "where_click", "target": "Export button"},
                                        session_memory=self.state)
        self.assertIn("could not be displayed", result)
        self.assertNotIn("I’ve highlighted", result)


if __name__ == "__main__":
    unittest.main()
