"""Installs the Python dependencies for THIS operating system only: the OS-specific
packages in requirements.txt carry `sys_platform` markers, so a macOS or Linux
user never pulls Windows-only libraries (and vice-versa). Then it fetches the
Playwright browsers needed for web automation (current-OS builds only).

Two things it deliberately does NOT install:
  * the optional local wake word ("Hey Jarvis") — one-click, opt-in, from
    ⚙ → WAKE WORD inside the app;
  * anything for the avatar — the holographic head renders in software on the
    PyQt6 and numpy already listed here. No GPU, no OpenGL, no extra packages.
"""
import platform
import subprocess
import sys
from pathlib import Path

OS = platform.system()  # "Windows" | "Darwin" | "Linux"
HERE = Path(__file__).resolve().parent

MIN_PY = (3, 11)        # hard floor: below this the syntax used here won't parse
MAX_PY = (3, 13)        # highest version this is actually tested on


def _run(label: str, args: list[str]) -> None:
    print(f"\n▶ {label}")
    subprocess.run(args, check=True)


def _check_python() -> None:
    """Fail immediately and clearly rather than deep inside a pip resolver.

    A wrong interpreter is the single most common way this install goes sideways,
    and the error it produces on its own names a wheel, not the real problem.
    """
    v = sys.version_info[:2]
    if v > MAX_PY:
        # Newer is a warning, not a wall. Turning away someone who installed
        # today's Python is a worse first impression than a version that
        # turns out to work fine, and if a wheel really is missing pip says
        # so plainly.
        print(f"\n⚠️  Python {v[0]}.{v[1]} is newer than the "
              f"{MAX_PY[0]}.{MAX_PY[1]} this is tested on. Continuing — if a "
              f"package has no wheel yet, install Python "
              f"{MAX_PY[0]}.{MAX_PY[1]} and run setup with that.")
        return
    if v < MIN_PY:
        print(f"\n❌ Python {v[0]}.{v[1]} detected — NOVA needs at "
              f"least Python {MIN_PY[0]}.{MIN_PY[1]}.")
        print("   Install a supported version and run setup with it, e.g.:")
        print(f"     py -{MIN_PY[0]}.{MIN_PY[1]} setup.py        (Windows)")
        print(f"     python{MIN_PY[0]}.{MIN_PY[1]} setup.py      (macOS / Linux)")
        sys.exit(1)


def _check_assets() -> None:
    """The avatar's face is a shipped file; a truncated clone should say so."""
    face = HERE / "core" / "face_model.obj"
    if not face.exists() or face.stat().st_size < 4096:
        print(
            "\n⚠️  core/face_model.obj is missing or truncated — the avatar will "
            "fall back to the plain glowing core.\n"
            "    Re-clone the repository, or fetch that one file again."
        )


def main() -> None:
    print(f"⚙  NOVA setup — detected OS: {OS or 'unknown'}, "
          f"Python {sys.version_info[0]}.{sys.version_info[1]}")
    _check_python()

    # requirements.txt filters OS-specific extras by itself via pip markers.
    _run("Installing Python dependencies (OS-specific extras auto-filtered)…",
         [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

    # Chromium covers Chrome/Edge/Opera/Brave/Vivaldi; Firefox for Firefox.
    # (Safari automation additionally needs: python -m playwright install webkit)
    # Not fatal: these are a few hundred megabytes from a CDN that a corporate
    # network or a flaky connection can refuse, and everything except browser
    # automation works without them. Failing the whole install there would send
    # a user away from a working app.
    try:
        _run("Installing Playwright browsers (chromium + firefox)…",
             [sys.executable, "-m", "playwright", "install", "chromium", "firefox"])
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"\n⚠️  Playwright browsers were not installed ({e}).")
        print("    Everything except browser automation works. Retry later with:")
        print(f'    {sys.executable} -m playwright install chromium firefox')

    _check_assets()

    # ── OS-specific post-install notes ────────────────────────────────────────
    if OS == "Windows":
        try:
            import win32com.client  # noqa: F401
        except ImportError:
            postinstall = Path(sys.executable).parent / "Scripts" / "pywin32_postinstall.py"
            print(
                "\n⚠️  pywin32 did not register correctly — desktop-shortcut "
                "creation will use a slower fallback. To fix it, run:\n"
                f'    "{sys.executable}" -m pip install --force-reinstall pywin32\n'
                f'    "{sys.executable}" "{postinstall}" -install'
            )
    elif OS == "Linux":
        print(
            "\nℹ️  Linux note — a few voice-controlled OS actions shell out to "
            "native tools. Install the ones you'll use via your package manager:\n"
            "    • volume      → pulseaudio-utils   (pactl)\n"
            "    • brightness  → brightnessctl\n"
            "    • reminders   → systemd (systemd-run) or 'at'\n"
            "    • open URLs   → xdg-utils          (xdg-open)"
        )
    elif OS == "Darwin":
        print(
            "\nℹ️  macOS note — volume, brightness and reminders use the built-in "
            "'osascript' / LaunchAgents, so no extra tools are required.\n"
            "    For Safari automation only: python -m playwright install webkit"
        )

    print("\n✅ Setup complete!")
    print("   1) Launch it:  python main.py")
    print("   2) Paste your free Gemini API key when the setup screen appears.")
    print("   3) (Optional) Enable 'Hey Jarvis' from ⚙ → WAKE WORD.")





def _smart_home_setup() -> None:
    """Configure Atomberg fans from this same setup.py. No second setup file."""
    try:
        from PyQt6.QtCore import Qt
        from PyQt6.QtWidgets import (
            QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
            QPushButton, QListWidget, QListWidgetItem, QMessageBox,
            QGroupBox, QFormLayout,
        )
        from smart_home.service import SmartHomeService
    except Exception as exc:
        print(f"\n❌ Smart-home setup cannot start: {exc}")
        print("   Run: python -m pip install requests PyQt6")
        return

    class SmartHomeSetup(QWidget):
        def __init__(self):
            super().__init__()
            self.service = SmartHomeService()
            self.discovered = []
            self.inputs = {}
            self.setWindowTitle("NOVA • Atomberg Fan Setup")
            self.resize(780, 670)
            self.setStyleSheet("""
                QWidget { background:#070b12; color:#e7f3ff; font-family:Segoe UI; }
                QLineEdit,QComboBox,QListWidget {
                    background:#0d1420; border:1px solid #26384c;
                    border-radius:6px; padding:8px; color:#e7f3ff;
                }
                QPushButton {
                    background:#10283b; border:1px solid #28b8ff;
                    border-radius:6px; padding:9px 14px; color:#bcecff;
                }
                QPushButton:hover { background:#16415b; }
                QGroupBox {
                    border:1px solid #26384c; border-radius:8px;
                    margin-top:10px; padding:12px;
                }
                QGroupBox::title { left:10px; padding:0 5px; color:#42c8ff; }
            """)

            root=QVBoxLayout(self)
            title=QLabel("NOVA • ATOMBERG FANS")
            title.setStyleSheet("font-size:22px;font-weight:700;color:#49caff;")
            root.addWidget(title)
            root.addWidget(QLabel(
                "Enter your Atomberg API credentials to discover and connect your fans."
            ))

            box=QGroupBox("Atomberg Credentials")
            form=QFormLayout(box)
            self.api_key=QLineEdit()
            self.api_key.setPlaceholderText("Atomberg API Key")
            self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
            form.addRow("API Key *",self.api_key)
            
            self.refresh_token=QLineEdit()
            self.refresh_token.setPlaceholderText("Atomberg Refresh Token")
            self.refresh_token.setEchoMode(QLineEdit.EchoMode.Password)
            form.addRow("Refresh Token *",self.refresh_token)
            root.addWidget(box)

            actions=QHBoxLayout()
            self.discover_btn=QPushButton("DISCOVER FANS")
            self.discover_btn.clicked.connect(self.discover)
            actions.addWidget(self.discover_btn)
            self.connect_btn=QPushButton("CONNECT SELECTED")
            self.connect_btn.clicked.connect(self.connect_selected)
            self.connect_btn.setEnabled(False)
            actions.addWidget(self.connect_btn)
            root.addLayout(actions)

            self.list=QListWidget()
            root.addWidget(self.list,1)
            self.status=QLabel(
                "Enter Atomberg credentials, then discover fans and select which ones NOVA should control."
            )
            self.status.setWordWrap(True)
            root.addWidget(self.status)

        def discover(self):
            api_key = self.api_key.text().strip()
            refresh_token = self.refresh_token.text().strip()
            if not api_key or not refresh_token:
                QMessageBox.warning(self,"Missing Credentials","Both API Key and Refresh Token are required.")
                return
            try:
                self.status.setText("Connecting to Atomberg and discovering fans...")
                QApplication.processEvents()
                result=self.service.preview_discovery(
                    "atomberg", {"api_key": api_key, "refresh_token": refresh_token}
                )
                self.discovered=result.get("devices") or []
                self.list.clear()
                for device in self.discovered:
                    name=device.get("name") or device.get("external_id") or "Atomberg Fan"
                    room=device.get("room") or "No room"
                    eid=str(device.get("external_id") or "")
                    item=QListWidgetItem(f"{name}  •  Fan  •  {room}")
                    item.setData(Qt.ItemDataRole.UserRole,eid)
                    item.setCheckState(Qt.CheckState.Checked)
                    self.list.addItem(item)
                self.status.setText(
                    f"Found {len(self.discovered)} fan(s). Select the fans NOVA should control."
                )
                self.connect_btn.setEnabled(True)
            except Exception as exc:
                QMessageBox.critical(self,"Discovery failed",str(exc))
                self.status.setText("Discovery failed. Check credentials and network.")

        def connect_selected(self):
            ids=[]
            for i in range(self.list.count()):
                item=self.list.item(i)
                if item.checkState()==Qt.CheckState.Checked:
                    ids.append(item.data(Qt.ItemDataRole.UserRole))
            if not ids:
                QMessageBox.warning(self,"Nothing selected","Select at least one fan.")
                return
            try:
                self.service.connect_devices(
                    "atomberg",
                    "Atomberg",
                    {"api_key": self.api_key.text().strip(), "refresh_token": self.refresh_token.text().strip()},
                    ids,
                )
                QMessageBox.information(
                    self,"NOVA Atomberg Fans",
                    "Fans connected successfully.\n\n"
                    "You can now say:\n"
                    "• Turn on the fan\n"
                    "• Turn off the fan\n"
                    "• Set the fan speed to 4\n"
                    "• Turn everything off"
                )
                self.status.setText(f"Connected {len(ids)} fan(s).")
            except Exception as exc:
                QMessageBox.critical(self,"Connection failed",str(exc))

    app=QApplication.instance() or QApplication(sys.argv)
    window=SmartHomeSetup()
    window.show()
    app.exec()


if __name__ == "__main__":
    if "--smart-home" in sys.argv:
        _smart_home_setup()
    else:
        main()
