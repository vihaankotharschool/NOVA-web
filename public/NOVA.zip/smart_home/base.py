"""Compatibility module for older NOVA smart-home imports.

Some older NOVA files imported ProviderField and SmartHomeProvider from
smart_home.base. The current package keeps them in smart_home.providers.base.
This bridge lets both import styles work, preventing the UI from failing to
load the provider dropdown.
"""
from .providers.base import ProviderField, SmartHomeProvider

__all__ = ["ProviderField", "SmartHomeProvider"]
