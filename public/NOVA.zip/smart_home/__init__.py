"""NOVA smart-home integration."""
from .service import SmartHomeService

__all__ = ["SmartHomeService"]
