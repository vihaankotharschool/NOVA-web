from __future__ import annotations

import time

import requests

from .base import ProviderField, SmartHomeProvider


class AtombergProvider(SmartHomeProvider):
    key = "atomberg"
    name = "Atomberg"
    available = True
    supported_device_types = ["fan"]

    # Built-in Atomberg API endpoint.
    # The user does NOT enter this in the UI.
    BASE_URL = "https://api.developer.atomberg-iot.com"

    @classmethod
    def auth_fields(cls):
        return [
            ProviderField(
                "api_key",
                "Atomberg API Key",
                secret=True,
            ),
            ProviderField(
                "refresh_token",
                "Atomberg Refresh Token",
                secret=True,
            ),
        ]

    def __init__(self):
        self._access_token = None
        self._token_expiry = 0.0

        self._session = requests.Session()

        # Do not use Windows/system proxy settings for the Atomberg API.
        self._session.trust_env = False

    # ------------------------------------------------------------------
    # AUTHENTICATION
    # ------------------------------------------------------------------

    def authenticate(self, credentials):
        api_key = str(
            credentials.get("api_key", "")
        ).strip()

        refresh_token = str(
            credentials.get("refresh_token", "")
        ).strip()

        if not api_key:
            raise ValueError(
                "Atomberg API key is required."
            )

        if not refresh_token:
            raise ValueError(
                "Atomberg refresh token is required."
            )

        access_token = self._get_access_token(
            api_key,
            refresh_token,
        )

        return {
            "account_label": "Atomberg Home",
            "credentials": {
                "api_key": api_key,
                "refresh_token": refresh_token,
                "access_token": access_token,
            },
        }

    def _get_access_token(
        self,
        api_key: str,
        refresh_token: str,
    ) -> str:

        # Reuse an existing access token while it is still valid.
        if (
            self._access_token
            and time.time()
            < self._token_expiry - 300
        ):
            return self._access_token

        url = (
            self.BASE_URL
            + "/v1/get_access_token"
        )

        headers = {
            "accept": "application/json",
            "x-api-key": api_key,
            "Authorization": (
                f"Bearer {refresh_token}"
            ),
        }

        try:
            response = self._session.get(
                url,
                headers=headers,
                timeout=15,
            )
        except requests.RequestException as exc:
            raise ValueError(
                f"Unable to connect to Atomberg: {exc}"
            ) from exc

        # Give the actual Atomberg response instead of
        # the generic requests "403 Client Error".
        if not response.ok:
            try:
                detail = response.json()
            except Exception:
                detail = response.text.strip()

            if not detail:
                detail = "No response body was provided."

            raise ValueError(
                "Atomberg credential check failed "
                f"(HTTP {response.status_code}): "
                f"{detail}"
            )

        try:
            data = response.json()
        except Exception as exc:
            raise ValueError(
                "Atomberg returned an invalid JSON response."
            ) from exc

        message = data.get("message") or {}

        access_token = message.get(
            "access_token"
        )

        if not access_token:
            raise ValueError(
                "Atomberg authentication failed: "
                f"{data}"
            )

        self._access_token = access_token

        # Keep the token for approximately 23 hours.
        self._token_expiry = (
            time.time() + 23 * 3600
        )

        return access_token

    # ------------------------------------------------------------------
    # API HEADERS
    # ------------------------------------------------------------------

    def _headers(self, credentials):
        api_key = str(
            credentials.get("api_key", "")
        ).strip()

        refresh_token = str(
            credentials.get("refresh_token", "")
        ).strip()

        access_token = self._get_access_token(
            api_key,
            refresh_token,
        )

        return {
            "accept": "application/json",
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "Authorization": (
                f"Bearer {access_token}"
            ),
        }

    # ------------------------------------------------------------------
    # DEVICE DISCOVERY
    # ------------------------------------------------------------------

    def discover_devices(self, credentials):
        headers = self._headers(credentials)

        url = (
            self.BASE_URL
            + "/v1/get_list_of_devices"
        )

        try:
            response = self._session.get(
                url,
                headers=headers,
                timeout=15,
            )
        except requests.RequestException as exc:
            raise ValueError(
                f"Unable to retrieve Atomberg devices: {exc}"
            ) from exc

        if not response.ok:
            try:
                detail = response.json()
            except Exception:
                detail = response.text.strip()

            raise ValueError(
                "Atomberg device discovery failed "
                f"(HTTP {response.status_code}): "
                f"{detail}"
            )

        try:
            data = response.json()
        except Exception as exc:
            raise ValueError(
                "Atomberg returned invalid device data."
            ) from exc

        raw_devices = (
            (data.get("message") or {})
            .get("devices_list")
        ) or []

        # --------------------------------------------------------------
        # Retrieve current device states.
        # --------------------------------------------------------------

        states = {}

        try:
            state_url = (
                self.BASE_URL
                + "/v1/get_device_state"
            )

            state_response = self._session.get(
                state_url,
                params={"device_id": "all"},
                headers=headers,
                timeout=15,
            )

            if state_response.ok:
                state_data = state_response.json()

                state_list = (
                    (state_data.get("message") or {})
                    .get("device_state")
                ) or []

                states = {
                    str(item.get("device_id")): item
                    for item in state_list
                    if isinstance(item, dict)
                }

        except Exception:
            # Device discovery itself should still work
            # if the optional state request fails.
            pass

        # --------------------------------------------------------------
        # Convert Atomberg devices into NOVA devices.
        # --------------------------------------------------------------

        result = []

        for device in raw_devices:
            device_id = str(
                device.get("device_id")
                or device.get("id")
                or ""
            )

            if not device_id:
                continue

            state = states.get(
                device_id,
                {},
            )

            result.append(
                {
                    "external_id": device_id,

                    "name": (
                        device.get("name")
                        or f"Atomberg Fan {device_id[-4:]}"
                    ),

                    "room": (
                        device.get("room")
                        or device.get("room_name")
                        or ""
                    ),

                    "manufacturer": "Atomberg",

                    "model": (
                        device.get("model")
                        or ""
                    ),

                    "device_type": "fan",

                    "is_on": bool(
                        state.get(
                            "power",
                            False,
                        )
                    ),

                    "traits": {
                        "speed": state.get(
                            "last_recorded_speed",
                            state.get("speed", 1),
                        ),

                        # Atomberg fan speed range currently
                        # represented by NOVA as 1-6.
                        "max_speed": 6,

                        "brightness": state.get(
                            "last_recorded_brightness"
                        ),

                        "led": state.get(
                            "led"
                        ),

                        "online": state.get(
                            "is_online",
                            device.get(
                                "online",
                                True,
                            ),
                        ),
                    },
                }
            )

        return result

    # ------------------------------------------------------------------
    # DEVICE CONTROL
    # ------------------------------------------------------------------

    def execute(
        self,
        device,
        action,
        payload,
    ):
        credentials = device[
            "provider_credentials"
        ]

        device_id = str(
            device["external_id"]
        )

        command = {
            "device_id": device_id,
            "command": {},
        }

        # --------------------------------------------------------------
        # Power
        # --------------------------------------------------------------

        if action == "power":
            is_on = bool(
                payload.get("is_on")
            )

            command["command"]["power"] = is_on

            if (
                is_on
                and payload.get("speed") is not None
            ):
                command["command"]["speed"] = int(
                    payload["speed"]
                )

        # --------------------------------------------------------------
        # Fan speed
        # --------------------------------------------------------------

        elif action == "speed":
            speed = int(
                payload.get("speed", 1)
            )

            command["command"]["speed"] = max(
                1,
                min(6, speed),
            )

        # --------------------------------------------------------------
        # Brightness
        # --------------------------------------------------------------

        elif action == "brightness":
            brightness = int(
                payload.get(
                    "brightness",
                    50,
                )
            )

            command["command"]["brightness"] = max(
                0,
                min(100, brightness),
            )

        # --------------------------------------------------------------
        # Fan mode
        # --------------------------------------------------------------

        elif action == "mode":
            mode = str(
                payload.get(
                    "mode",
                    "",
                )
            ).lower()

            command["command"]["mode"] = mode

        # --------------------------------------------------------------
        # Restart
        # --------------------------------------------------------------

        elif action == "restart":
            raise ValueError(
                "Restart is not supported by "
                "the Atomberg public API."
            )

        else:
            raise ValueError(
                f"Unsupported Atomberg action: {action}"
            )

        # --------------------------------------------------------------
        # Send command to Atomberg
        # --------------------------------------------------------------

        url = (
            self.BASE_URL
            + "/v1/send_command"
        )

        try:
            response = self._session.post(
                url,
                json=command,
                headers=self._headers(
                    credentials
                ),
                timeout=15,
            )
        except requests.RequestException as exc:
            raise ValueError(
                f"Unable to control Atomberg device: {exc}"
            ) from exc

        if not response.ok:
            try:
                detail = response.json()
            except Exception:
                detail = response.text.strip()

            raise ValueError(
                "Atomberg command failed "
                f"(HTTP {response.status_code}): "
                f"{detail}"
            )

        try:
            data = response.json()
        except Exception as exc:
            raise ValueError(
                "Atomberg returned an invalid command response."
            ) from exc

        if data.get("status") not in (
            None,
            "Success",
        ):
            raise ValueError(
                f"Atomberg command failed: {data}"
            )

        # --------------------------------------------------------------
        # Update NOVA's local device state.
        # --------------------------------------------------------------

        is_on = command[
            "command"
        ].get(
            "power",
            device.get(
                "is_on",
                False,
            ),
        )

        traits = dict(
            device.get("traits") or {}
        )

        traits.update(
            command["command"]
        )

        if "speed" in command["command"]:
            traits["speed"] = command[
                "command"
            ]["speed"]

        detail = self._detail(
            device.get(
                "name",
                "Atomberg fan",
            ),
            action,
            command["command"],
        )

        return {
            "is_on": bool(is_on),
            "traits": traits,
            "detail": detail,
        }

    # ------------------------------------------------------------------
    # HUMAN-READABLE ACTION RESULT
    # ------------------------------------------------------------------

    @staticmethod
    def _detail(
        name,
        action,
        command,
    ):
        if action == "power":
            return (
                f"{name} turned "
                f"{'on' if command.get('power') else 'off'}."
            )

        if action == "speed":
            return (
                f"{name} speed set to "
                f"{command.get('speed')}."
            )

        if action == "brightness":
            return (
                f"{name} brightness set to "
                f"{command.get('brightness')}%."
            )

        if action == "mode":
            return (
                f"{name} mode set to "
                f"{command.get('mode')}."
            )

        return f"{name} updated."


# ----------------------------------------------------------------------
# NOVA PROVIDER REGISTRY
# ----------------------------------------------------------------------
#
# Atomberg is intentionally the ONLY built-in smart-home provider.
# There is no Home Assistant / Universal provider here.
# ----------------------------------------------------------------------

def built_in_provider_classes():
    return [
        AtombergProvider,
    ]