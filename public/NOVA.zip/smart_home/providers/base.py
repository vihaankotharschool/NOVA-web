from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class ProviderField:
    key: str
    label: str
    secret: bool = False
    required: bool = True

class SmartHomeProvider:
    key = "base"
    name = "Base"
    available = False
    coming_soon = True
    supported_device_types: list[str] = []

    @classmethod
    def auth_fields(cls) -> list[ProviderField]:
        return []

    def authenticate(self, credentials: dict[str, Any]) -> dict[str, Any]:
        return {"account_label": self.name, "credentials": credentials}

    def discover_devices(self, credentials: dict[str, Any]) -> list[dict[str, Any]]:
        raise NotImplementedError

    def execute(self, device: dict[str, Any], action: str, payload: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError
