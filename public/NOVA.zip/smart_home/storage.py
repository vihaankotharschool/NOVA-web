from __future__ import annotations

import copy
import time
import uuid
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parents[1]
CONFIG_DIR = BASE_DIR / "config"
STORE_PATH = CONFIG_DIR / "smart_home.json"


def _default() -> dict[str, Any]:
    return {"accounts": {}, "devices": {}, "activity": []}


class SmartHomeStorage:
    def __init__(self, path: Path | None = None):
        self.path = path or STORE_PATH
        self._data = _default()

    def _read(self) -> dict[str, Any]:
        return copy.deepcopy(self._data)

    def _write(self, data: dict[str, Any]) -> None:
        self._data = copy.deepcopy(data)

    def find_provider_account(self, provider_key: str, credentials: dict[str, Any]) -> dict[str, Any] | None:
        """Return an existing account for the same provider and credentials."""
        accounts = self._read().get("accounts", {})
        for account in accounts.values():
            if account.get("provider_key") != provider_key:
                continue
            saved = account.get("credentials") or {}
            # Ignore short-lived access tokens when comparing persisted credentials.
            a = {k: v for k, v in saved.items() if k != "access_token"}
            b = {k: v for k, v in (credentials or {}).items() if k != "access_token"}
            if a == b:
                return account
        return None

    def save_provider_account(self, provider_key: str, label: str, credentials: dict[str, Any]) -> str:
        data = self._read()
        account_id = str(uuid.uuid4())
        data.setdefault("accounts", {})[account_id] = {
            "id": account_id,
            "provider_key": provider_key,
            "label": label or provider_key,
            "credentials": credentials,
            "created_at": time.time(),
        }
        self._write(data)
        return account_id

    def get_provider_account(self, account_id: str) -> dict[str, Any] | None:
        return self._read().get("accounts", {}).get(account_id)

    def save_devices(self, account_id: str, provider_key: str, devices: list[dict[str, Any]]) -> None:
        data = self._read()
        store = data.setdefault("devices", {})
        for device in devices:
            external_id = str(device.get("external_id", "")).strip()
            existing_id = None
            if external_id:
                for did, existing in store.items():
                    if (existing.get("provider_key") == provider_key and
                            str(existing.get("external_id", "")) == external_id):
                        existing_id = did
                        break

            device_id = existing_id or str(uuid.uuid4())
            old = store.get(device_id, {})
            clean = dict(device)
            clean["id"] = device_id
            clean["provider_account_id"] = account_id
            clean["provider_key"] = provider_key
            clean.setdefault("name", old.get("name") or clean.get("external_id", "Smart Device"))
            clean.setdefault("room", old.get("room", ""))
            clean.setdefault("device_type", old.get("device_type", "unknown"))
            clean.setdefault("is_on", old.get("is_on", False))
            clean.setdefault("traits", old.get("traits", {}))
            # Keep a user's custom name when a provider refreshes the device.
            if old.get("custom_name"):
                clean["name"] = old["name"]
                clean["custom_name"] = True
            store[device_id] = clean
        self._write(data)

    def list_devices(self, search: str = "", room: str = "") -> list[dict[str, Any]]:
        devices = list(self._read().get("devices", {}).values())
        s, r = search.lower().strip(), room.lower().strip()
        if s:
            devices = [d for d in devices if s in str(d.get("name", "")).lower() or s in str(d.get("external_id", "")).lower()]
        if r:
            devices = [d for d in devices if r in str(d.get("room", "")).lower()]
        return devices

    def get_device(self, device_id: str) -> dict[str, Any] | None:
        return self._read().get("devices", {}).get(device_id)

    def update_device(self, device_id: str, **updates: Any) -> None:
        data = self._read()
        if device_id in data.get("devices", {}):
            data["devices"][device_id].update({k: v for k, v in updates.items() if v is not None})
            self._write(data)

    def forget_device(self, device_id: str) -> None:
        data = self._read()
        data.get("devices", {}).pop(device_id, None)
        self._write(data)

    def forget_account_if_unused(self, account_id: str) -> bool:
        """Delete a saved provider account when no devices still use it."""
        data = self._read()
        devices = data.get("devices", {})
        if any(str(d.get("provider_account_id", "")) == str(account_id) for d in devices.values()):
            return False
        removed = data.get("accounts", {}).pop(account_id, None) is not None
        if removed:
            self._write(data)
        return removed

    def rename_device(self, device_id: str, name: str) -> None:
        self.update_device(device_id, name=name.strip())

    def count_devices(self) -> int:
        return len(self._read().get("devices", {}))

    def log_activity(self, device_name: str, detail: str) -> None:
        data = self._read()
        activity = data.setdefault("activity", [])
        activity.insert(0, {"time": time.time(), "device": device_name, "detail": detail})
        del activity[50:]
        self._write(data)

    def recent_activity(self, limit: int = 10) -> list[dict[str, Any]]:
        return self._read().get("activity", [])[:max(1, int(limit))]
